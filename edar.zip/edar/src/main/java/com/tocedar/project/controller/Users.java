package com.tocedar.project.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validator;
import javax.validation.constraints.AssertTrue;
import javax.validation.executable.ExecutableValidator;
import javax.validation.metadata.BeanDescriptor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.http.HttpRequest;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tocedar.project.model.Assignment;
import com.tocedar.project.model.SubRole;
import com.tocedar.project.model.SubRoleId;
import com.tocedar.project.model.User;
import com.tocedar.project.model.UserCredentials;
import com.tocedar.project.model.UserRoles;
import com.tocedar.project.repositories.AssignmentRepository;
import com.tocedar.project.repositories.DepartmentRepository;
import com.tocedar.project.repositories.SubRoleRepository;
import com.tocedar.project.repositories.TaskRepository;
import com.tocedar.project.repositories.UserCredentialRepository;
import com.tocedar.project.repositories.UserRepository;
import com.tocedar.project.repositories.UserRoleRepository;
import com.tocedar.project.validation.FieldValidator;

@Validated
@Controller
public class Users{
	
	private UserRepository userRepository;
	private DepartmentRepository deptRepository;
	private TaskRepository taskRepository;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private AssignmentRepository assignmentRepository;
	
	@Autowired
	private UserCredentialRepository credentialRepository;
	
	@Autowired private SubRoleRepository subRoleRepository;
	
	@Autowired private UserRoleRepository userRoleRepository;
	
	@Autowired
	public void setTaskRepository(TaskRepository taskRepository) {
		this.taskRepository = taskRepository;
	}

	@Autowired
	public void setDeptRepository(DepartmentRepository deptRepository) {
		this.deptRepository = deptRepository;
	}

	@Autowired
	public void setUserRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@RequestMapping(value="/admin/users")
	public String index(Model model){
		
		model.addAttribute("usersList",userRepository.findAll());
		model.addAttribute("assignment",new Assignment());
		model.addAttribute("task",taskRepository.findAll());
		model.addAttribute("dept",deptRepository.findAll());
		model.addAttribute("role",userRoleRepository.findAll());
		
		List<String> ass_type = new ArrayList<>();
		ass_type.add("Date range");
		ass_type.add("Time alloted(fixed)");
		ass_type.add("Time alloted(flex)");
		
		model.addAttribute("assignment_type1",ass_type);
		model.addAttribute("assignment",new Assignment());
		model.addAttribute("user",new User());
		
		return "manage/user";
	}
	
	@RequestMapping(value="/admin/usersFilter")
	public @ResponseBody List<User> userSeach(@RequestParam(value="search") String search,@RequestParam(value="position") String position){
		
		System.out.println("hey sunshine!!!");
		
		return userRepository.findByFirstnameContainingOrLastnameContainingAndPositionEquals(search, search,position);
	}
	
	@RequestMapping(value="/admin/search")
	public @ResponseBody List<User> search(@RequestParam(value="position",required=false) String position,
											@RequestParam(value="name",required=false) String name,
											@RequestParam(value="department",required=false) Integer dept){
		
		System.out.println("position:"+position);
		System.out.println("department:"+dept);
		
		if(name == null){
			
			if(position.equals("all") && dept == 0){
				System.out.println("find all");
				return (List)userRepository.findAll();
			}else if(!position.equals("all") && dept == 0){
				System.out.println("find by position");
				return userRepository.findByPosition(position);
			}else if(position.equals("all") && dept != 0){
				System.out.println("find by department");
				return userRepository.findByUserDepartmentId(dept);
			}
			
			System.out.println("empty name:");
			
			return userRepository.findByUserDepartmentIdAndPosition(dept, position);
		}else{
			
			if(dept == null && position == null){
				if(name.isEmpty()){
					return (List) userRepository.findAll();
				}
				return userRepository.findByLastnameContainingOrFirstnameContaining(name, name);
				
			}else{
				if(dept == 0){
					System.out.println("only position");
					return userRepository.findByPositionAndFirstnameContainingOrLastname(position, name,name);
				}
				
				if(position.equals("all")){
					System.out.println("only dept");
					return userRepository.findByUserDepartmentIdAndFirstnameContainingOrLastname(dept, name, name);
				}
				System.out.println("find by dept,pos,name");
				return userRepository.findByUserDepartmentIdAndPositionAndLastnameContainingOrFirstnameContaining(dept, position, name,name);
			}
		}
		
		
	}
	
	@RequestMapping(value="/admin/users-list",produces=MediaType.APPLICATION_JSON_VALUE,method=RequestMethod.GET)
	public @ResponseBody List<User> listUser(@RequestParam(value="hide-inactive",required = false) boolean inActive){
		
		List<User> users_list = (List)userRepository.findAll();
		
		if(inActive){
			users_list =  userRepository.findByStatus(1);
		}else{
			users_list = (List)userRepository.findAll();
		}
		
		return users_list;
	}
	
	@RequestMapping(value="/admin/users-list-by-multiple-dept/{departmentList}",method=RequestMethod.GET)
	public @ResponseBody List<User> listUserByMultipleDept(@PathVariable(value="departmentList") List<Integer> deptId1){
		for(Integer in:deptId1){
			System.out.println("dept:"+in);
		}
		return (List) userRepository.getUserListMultipleDepartment(deptId1);
	}
	
	@RequestMapping(value="/admin/getUserAssignment/{id}")
	public @ResponseBody String getUserAssignedTask(@PathVariable int id){
		
		return "hey";
	}
	
	@RequestMapping(value="/admin/user-info/{id}")
	public String getUserInfo(@PathVariable int id,Model model){
		
		model.addAttribute("info",userRepository.findOne(id));
		
		return "manage/userInformation";
	}
	
	@RequestMapping(value="/admin/get-user-info/{id}",produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody User getUserInfo(@PathVariable int id){
		return userRepository.findOne(id);
	}
	
	@RequestMapping(value="/admin/user-edit/{id}")
	public String editUser(@PathVariable Integer id,Model model){
		
		model.addAttribute("deparments",deptRepository.findAll());
		model.addAttribute("user",userRepository.findOne(id));
		
		User us = userRepository.findOne(id);
		System.out.println("user id:"+id);
		List<SubRole> rl = us.getSubRole();
		for(SubRole s:rl){
			System.out.println("Role:"+s.getRole().getRole());
		}
		
		model.addAttribute("role",userRoleRepository.findAll());
		model.addAttribute("action","edit");
		
		return "data-management/createUser";
	}
	
	@RequestMapping(value="/admin/user-add")
	public String addUser(Model model){
		model.addAttribute("deparments",deptRepository.findAll());
		model.addAttribute("user",new User());
		model.addAttribute("action","add");
		model.addAttribute("role",userRoleRepository.findAll());
		return "data-management/createUser";
	}
	
	@RequestMapping(value="/admin/activation/{flag_activate}/{id_user}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String,String> userActivation(@PathVariable int flag_activate,@PathVariable int id_user){
		Map<String,String> activation = new HashMap<>();
		
		User user_activation = userRepository.findOne(id_user);
		user_activation.setStatus(flag_activate);
		
		activation.put("message", "Activation success");
		activation.put("id", Integer.toString(user_activation.getId()));
		activation.put("status", Integer.toString(user_activation.getStatus()));
		
		userRepository.save(user_activation);
		
		return activation;
	}
	
	@RequestMapping(value="/admin/get-user-assignment/{id_select}",method=RequestMethod.GET)
	public String userAssignment(@PathVariable int id_select,Model model){
		
		User user = userRepository.findOne(id_select);
		
		List<String> ass_type = new ArrayList<>();
		ass_type.add("Date range");
		ass_type.add("Time alloted(fixed)");
		ass_type.add("Time alloted(flex)");
		
		model.addAttribute("id_select",id_select);
		model.addAttribute("name_user",user.getFirstname() + " " + user.getLastname());
		model.addAttribute("assignmentList",assignmentRepository.assignedTask(new User(id_select)));
		model.addAttribute("assignment",new Assignment(new User(id_select)));
		model.addAttribute("task",taskRepository.findAll());
		model.addAttribute("assignment_type1",ass_type);
		
		return "manage/user-assigned-list";
	}
	
	@RequestMapping(value="/admin/user-create",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String,Object> createUser(Model model,@Valid User user,BindingResult result,Errors error){
		
		try{
			UserCredentials use = credentialRepository.findByUsername(user.getUser_cred().getUsername());
			
			System.out.println("user:"+use.getUsername().toString());
			if(!use.getUsername().toString().isEmpty()){
				error.rejectValue("user_cred.username","userExist","Username Already exists!");
			}
		}catch(NullPointerException e){
			System.out.println("user not exists");
		}
		
		ValidationUtils.rejectIfEmpty(error, "user_cred.username", "usernameRequired","Username must not empty");
		
		Map<String,List<ObjectError>> resultObj = new HashMap<String,List<ObjectError>>();
		
		FieldValidator fv = new FieldValidator();
		fv.validatePassword(user.getUser_cred(), result);
		fv.validateUsername(user.getUser_cred().getUsername(), result);
		
		UserCredentials cred = user.getUser_cred();
		cred.setUsername(user.getUser_cred().getUsername());
		cred.setPassword(bCryptPasswordEncoder.encode(user.getUser_cred().getPassword()));
		cred.setConfirmPassword(bCryptPasswordEncoder.encode(user.getUser_cred().getConfirmPassword()));
		
		cred.setUser_info(user);
		
		System.out.println("user role:"+user.getSubRole());
		
		/*for(SubRole sr:cred.getUser_info().getSubRole()){
			System.out.println("role:"+sr.getRole().getRole());
		}*/
		
		//subRoleRepository.save(sb);
		
		Map<String,Object> res = new HashMap<>();
	
		if(result.hasErrors()){
			res.put("error", result.getAllErrors());
		}else{
			
			User usr = credentialRepository.save(cred).getUser_info();
			
			List<SubRole> sb = new ArrayList<>();
			
			for(SubRole sd:cred.getUser_info().getSubRole()){
			
				System.out.println("user:"+sd.getRole().getUser_role_id());
				System.out.println("user1:"+user.getId());
			
				SubRole sub = new SubRole();
				sub.setSub_role_id(new SubRoleId(sd.getRole().getUser_role_id(),usr.getId()));
				sb.add(sub);
				
			}
			
			subRoleRepository.save(sb);
			
			res.put("user", usr);
			
		}
		
		return res;
	}

	@RequestMapping(value="/admin/updateUser/{isChangePassword}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String,List<ObjectError>> editUserInfo(@PathVariable Integer isChangePassword,@Valid User user,Errors errors,BindingResult result,HttpServletRequest confirm_password){
		
		User userInfo = userRepository.findOne(user.getId());
		UserCredentials cred = credentialRepository.findOne(user.getUser_cred().getId());
		
		userInfo.setEmail(user.getEmail());
		userInfo.setFirstname(user.getFirstname());
		userInfo.setLastname(user.getLastname());
		userInfo.setPosition(user.getPosition());
		userInfo.setStatus(user.getStatus());
		userInfo.setUserDepartment(user.getUserDepartment());
		//userInfo.setUser_role(user.getUser_role());
		userInfo.setDate_created(user.getDate_created());
		
		System.out.println("change:"+isChangePassword);
		
		if(isChangePassword<=0){
			
			FieldValidator fv = new FieldValidator();
			fv.validatePassword(user.getUser_cred(), result);
			fv.validateUsername(user.getUser_cred().getUsername(), result);
			
			cred.setUsername(user.getUser_cred().getUsername());
			cred.setPassword(user.getUser_cred().getPassword());
			
			userInfo.setUser_cred(cred);
		}
		
		//ValidationUtils.rejectIfEmpty(errors, field, errorCode);
		
		Map<String,List<ObjectError>> resp1 = new HashMap<String,List<ObjectError>>();
			
		if(result.hasErrors()){
			resp1.put("Error", result.getAllErrors());
		}else{
			
			List<SubRole> sb = new ArrayList<>();
			
			subRoleRepository.DeleteByUserId(userInfo);
			
			for(SubRole sd:user.getSubRole()){
			
				SubRole sub = new SubRole();
				sub.setSub_role_id(new SubRoleId(sd.getRole().getUser_role_id(),userInfo.getId()));
				
				sb.add(sub);
			}
			
			subRoleRepository.save(sb);
			
			userRepository.save(userInfo);
		}
		
		return resp1;
	}
}
