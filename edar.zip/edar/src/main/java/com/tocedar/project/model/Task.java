package com.tocedar.project.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;


@Entity
@Table(name="edr_task")
//@JsonIdentityInfo(generator=ObjectIdGenerators.IntSequenceGenerator.class,property="@taskId")
public class Task {
	
	Integer id;
	
	@NotEmpty
	String task_name;
	
	@NotEmpty
	String code;
	
	Integer id_manager;
	
	@NotEmpty
	String description;
	
	@NotEmpty
	String contact_person;
	
	String default_task;
	
	String billable;
	
	String active;
	
	String user_assigned;
	
	String task_color;
	
	List<UserTask> userTask;
	
	List<Assignment> assigned_task;
	
	public Task(int id){
		this.id = id;
	}
	
	public Task(){
		
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public Integer getId() {
		return id;
	}
	public void setId(Integer id1) {
		this.id = id1;
	}
	
	@Column(name="description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	@Column(name="task_name")
	public String getTask_name() {
		return task_name;
	}
	public void setTask_name(String task_name) {
		this.task_name = task_name;
	}
	
	@Column(name="code")
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}

	@Column(name="id_manager")
	public Integer getId_manager() {
		return id_manager;
	}
	public void setId_manager(Integer id_manager) {
		this.id_manager = id_manager;
	}
	
	@Column(name="contact_person")
	public String getContact_person() {
		return contact_person;
	}
	public void setContact_person(String contact_person) {
		this.contact_person = contact_person;
	}
	
	@Column(name="default_task")
	public String getDefault_task() {
		return default_task;
	}
	public void setDefault_task(String default_task) {
		this.default_task = default_task;
	}
	
	@Column(name="billable")
	public String getBillable() {
		return billable;
	}
	public void setBillable(String billable) {
		this.billable = billable;
	}
	
	@Column(name="active")
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	
	@Column(name="user_assigned")
	public String getUser_assigned() {
		return user_assigned;
	}
	public void setUser_assigned(String user_assigned) {
		this.user_assigned = user_assigned;
	}
	
	@Column(name="task_color")
	public String getTask_color() {
		return task_color;
	}
	public void setTask_color(String task_color) {
		this.task_color = task_color;
	}
	
	@JsonIgnore
	@OneToMany(cascade = CascadeType.DETACH,
			fetch=FetchType.EAGER,
			mappedBy="assignment")
	public List<UserTask> getUserTask() {
		return userTask;
	}
	public void setUserTask(List<UserTask> task) {
		this.userTask = task;
	}
	
	@JsonIgnore
	@OneToMany(cascade = CascadeType.DETACH,
			mappedBy="user_assignment")
	public List<Assignment> getAssigned_task() {
		return assigned_task;
	}
	public void setAssigned_task(List<Assignment> assigned_task) {
		this.assigned_task = assigned_task;
	}
}
