package com.tocedar.project;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

public class Methods {
	
	private Logger log = Logger.getLogger(Methods.class);
	
	public Date getDateNow(String format){

		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		Date now = null;
		try {
			now = dateFormat.parse(dateFormat.format(new Date()));
		} catch (ParseException e) {
			
			//e.printStackTrace();
			log.error("Error:"+e.getMessage());
		}
		
		return now;
	}
	
	public int TimeConsume(Time tm_in,Time tm_out){
		
		@SuppressWarnings("deprecation")
		int hours = ((tm_out.getHours()*60 + tm_out.getMinutes()) - (tm_in.getHours()*60 + tm_in.getMinutes()));
		
		return hours ;
	}
}
