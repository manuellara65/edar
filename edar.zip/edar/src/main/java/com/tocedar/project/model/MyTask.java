package com.tocedar.project.model;

import java.sql.Time;

public class MyTask {

	String owner_description;
	Time time_in;
	Time time_out;
	String task_name;
	int id;
	
	public MyTask(String owner_description,Time time_in,Time time_out,String task_name,int id ){
		this.owner_description = owner_description;
		this.time_in = time_in;
		this.time_out = time_out;
		this.task_name = task_name;
		this.id = id;
	}
	
	public String getOwner_description() {
		return owner_description;
	}
	public void setOwner_description(String owner_description) {
		this.owner_description = owner_description;
	}
	public Time getTime_in() {
		return time_in;
	}
	public void setTime_in(Time time_in) {
		this.time_in = time_in;
	}
	public Time getTime_out() {
		return time_out;
	}
	public void setTime_out(Time time_out) {
		this.time_out = time_out;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getTask_name() {
		return task_name;
	}

	public void setTask_name(String task_name) {
		this.task_name = task_name;
	}
	
	
}
