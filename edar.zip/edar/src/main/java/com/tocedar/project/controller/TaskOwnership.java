package com.tocedar.project.controller;

import java.sql.ResultSet;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tocedar.project.Methods;
import com.tocedar.project.model.Assignment;
import com.tocedar.project.model.CreateReport;
import com.tocedar.project.model.User;
import com.tocedar.project.model.UserTask;
import com.tocedar.project.repositories.AssignmentRepository;
import com.tocedar.project.repositories.UserRepository;
import com.tocedar.project.repositories.UserTaskRepository;

@Controller
public class TaskOwnership {

	@Autowired
	private UserTaskRepository userTaskRepo;
	
	 UserRepository userRepository;
	
	@Autowired AssignmentRepository assignmentRepository;
	int userId;
	
	@Autowired
	public void setUserTaskRepo(UserTaskRepository userTaskRepo) {
		this.userTaskRepo = userTaskRepo;
	}
	
	@RequestMapping(value="/user/createMyTask",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String,Object> createOwnTask(Model model,@Valid UserTask user,BindingResult result,Error error,HttpSession session,HttpServletRequest request) throws ParseException{
		
		int tm = Integer.parseInt(request.getParameter("total_time_consumed"));
		int ttl_time = tm + new Methods().TimeConsume(user.getTime_in(), user.getTime_out());
		
		if(new Methods().TimeConsume(user.getTime_in(), user.getTime_out()) <=0){
			result.rejectValue("time_in", "InvalidTimeAlloted","Invalid Time Input!");
			result.rejectValue("time_out", "InvalidTimeAlloted","Invalid Time Input!");
		}
		
		if(result.hasErrors()){
			Map<String,Object> errorResult = new HashMap<>();
			errorResult.put("error", result.getAllErrors());
			
			return errorResult;
		}else{
			
			userId = Integer.parseInt(session.getAttribute("userId").toString());
			
			UserTask userTaskCreated = userTaskRepo.save(user);
			
			return ownerTaskInfo(userTaskCreated,ttl_time);
		}
		
		
	}
	
	@RequestMapping(value="/user/getMyTaskInfo/{id}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String,Object> getMyTaskInfo(@PathVariable int id){
		
		UserTask getUserTaskInfo = userTaskRepo.findOne(id);
		
		return ownerTaskInfo(getUserTaskInfo,0);
	}
	
	@RequestMapping(value="/user/updateMyTask",method=RequestMethod.GET)
	public @ResponseBody Map<String,Object> updateMyTask(@Valid UserTask userTaskUpdate,BindingResult result,Error error,HttpServletRequest request){
		
		if(new Methods().TimeConsume(userTaskUpdate.getTime_in(), userTaskUpdate.getTime_out()) <= 0){
			result.rejectValue("time_in", "InvalidTimeInput","Invalid Time Input!");
			result.rejectValue("time_out", "InvalidTimeInput","Invalid Time Input!");
		}
		
		if(result.hasErrors()){
			Map<String,Object> errorResult = new HashMap<>();
			errorResult.put("error", result.getAllErrors());
			
			return errorResult;
		}else{
			
			int tm = Integer.parseInt(request.getParameter("total_time_consumed"));
			
			UserTask getUserTaskInfo = userTaskRepo.findOne(userTaskUpdate.getId());
			
			int ttl_time1 = tm - (new Methods().TimeConsume(getUserTaskInfo.getTime_in(), getUserTaskInfo.getTime_out()));
			
			int ttl_time = ttl_time1 + (new Methods().TimeConsume(userTaskUpdate.getTime_in(), userTaskUpdate.getTime_out()));
			
			getUserTaskInfo.setAssignment(userTaskUpdate.getAssignment());
			getUserTaskInfo.setOwner_description(userTaskUpdate.getOwner_description());
			getUserTaskInfo.setDateCreated(userTaskUpdate.getDateCreated());
			getUserTaskInfo.setTime_in(userTaskUpdate.getTime_in());
			getUserTaskInfo.setTime_out(userTaskUpdate.getTime_out());
			
			return ownerTaskInfo(userTaskRepo.save(getUserTaskInfo),ttl_time);
		}
		
	}
	
	@RequestMapping(value="/user/resetUserTask",method=RequestMethod.GET)
	public @ResponseBody Map<String,Object> updteMyTask(UserTask userTaskReset,HttpServletRequest request){
		
		int tm = Integer.parseInt(request.getParameter("total_time_consumed"));
		
		int ttl_time = tm - (new Methods().TimeConsume(userTaskReset.getTime_in(), userTaskReset.getTime_out()));
		
		UserTask usertask = userTaskRepo.findOne(userTaskReset.getId());
		
		userTaskRepo.delete(userTaskReset.getId());
		
		return ownerTaskInfo(userTaskReset,ttl_time);
	}
	
	@RequestMapping(value="/user/user-owned-task/getOwnTaskForReport",method=RequestMethod.POST,produces="application/json")
	public @ResponseBody Map<String,Object> getUserAssignmetForReport(CreateReport createReport,
																	Model model,
																	BindingResult result,
																	Errors errors,
																	HttpSession session) throws ParseException{

		ValidationUtils.rejectIfEmpty(errors, "from_dt", "RequiredField","Missing Field!");
		ValidationUtils.rejectIfEmpty(errors, "until_dt", "RequiredField","Missing Field!");
		ValidationUtils.rejectIfEmpty(errors, "taskList", "RequiredField","Missing/Empty Field!");
		
		Map<String,Object> res = new HashMap<String,Object>();
		if(result.hasErrors()){
			res.put("error", errors.getAllErrors());
		}else{
			int userId = Integer.parseInt(session.getAttribute("userId").toString());
			
			DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
			
			Date startDate1 = createReport.getFrom_dt();
			Date endDate1 = createReport.getUntil_dt();
			
			String sd = format1.format(startDate1);
			
			System.out.println("start date:"+startDate1);
			System.out.println("end date:"+endDate1);
			System.out.println("userId"+userId);
			
			List<UserTask> listForReport = userTaskRepo.findBetweenDatesAndAssignedTask(userId, startDate1, endDate1, createReport.getTaskList());
			
			res.put("result", listForReport);
		}
		
		return res;
	}
	
	public Map<String,Object> ownerTaskInfo(UserTask ownerTask,int ttl_time1){
		Map<String,Object> ownTask = new HashMap<String,Object>();
		
		ownTask.put("owner_description",ownerTask.getOwner_description());
		ownTask.put("date_created", ownerTask.getDateCreated().toString());
		ownTask.put("id", Integer.toString(ownerTask.getId()));
		ownTask.put("id_task", Integer.toString(ownerTask.getAssignment().getUser_assignment().getId()));
		ownTask.put("task_name", ownerTask.getAssignment().getUser_assignment().getTask_name());
		ownTask.put("time_in", ownerTask.getTime_in().toString());
		ownTask.put("time_out", ownerTask.getTime_out().toString());
		ownTask.put("total_time", Integer.toString((ttl_time1)));
		ownTask.put("total_time_word", ttl_time1/60 +" hrs and " + ttl_time1%60 + " mins.");
		
		return ownTask;
	}
	
	
	
	
}
