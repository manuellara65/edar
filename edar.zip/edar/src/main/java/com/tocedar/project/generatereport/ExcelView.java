
package com.tocedar.project.generatereport;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.tocedar.project.Methods;
import com.tocedar.project.model.UserTask;

public class ExcelView extends AbstractExcelView{

	HSSFSheet sheet;
	@Override
	protected void buildExcelDocument(Map<String, Object> model, HSSFWorkbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String sheetname = model.get("sheetname").toString();
		Integer reportCategory = (Integer) model.get("category");
		List<String> header = (List<String>) model.get("header");
		List<UserTask> result = (List<UserTask>) model.get("results");
		List<Date> dt = (List<Date>) model.get("dateRange");
		
		sheet = workbook.createSheet(sheetname);
		sheet.setDefaultColumnWidth(20);
		
		//set cell style
		HSSFCellStyle headerStyle = workbook.createCellStyle();
		headerStyle.setFillForegroundColor(HSSFColor.SKY_BLUE.index);
		headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		
		HSSFFont fontStyle = workbook.createFont();
		fontStyle.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		
		headerStyle.setFont(fontStyle);
		
		HSSFRow dateRange = sheet.createRow(0);
		
		HSSFCell start = dateRange.createCell(0);
		HSSFRichTextString start1 = new HSSFRichTextString("Start Date: ");
		start.setCellValue(start1);
		
		HSSFCell endDate = dateRange.createCell(2);
		HSSFRichTextString endDate1 = new HSSFRichTextString("End Date: ");
		endDate.setCellValue(endDate1);
		
		List<String> use = new ArrayList<String>();
		
		int ctr=0;
		int ctr_cell = 1;
		for(Date dates:dt){
			HSSFCell range = dateRange.createCell(ctr_cell);
			HSSFRichTextString range1 = new HSSFRichTextString(""+dt.get(ctr));
			range.setCellValue(range1);
			ctr++;
			ctr_cell+=2;
		}
		
		//set header value
		int row_header = 0;
		
		
		HSSFRow header_data = sheet.createRow(2);
		for(String col:header){
			HSSFRichTextString text = new HSSFRichTextString(col);
			HSSFCell cell = header_data.createCell(row_header);
			cell.setCellStyle(headerStyle);
			cell.setCellValue(text);
			row_header++;
		}
		
		if(reportCategory == 0){
			userReport(result);
		}else if(reportCategory == 1){
			userReportDetaild(result);
		}else if(reportCategory == 2){
			userReportAggregatedTask(result);
		}else if(reportCategory == 3){
			userReportAggregatedUser(result);
		}
	}
	
	private void userReportAggregatedTask(List<UserTask> result){
		int row_body = 3;
		
		for(UserTask sd:result){
			
			HSSFRow body_data = sheet.createRow(row_body);
			
			body_data.createCell(0).setCellValue(sd.getAssignment().getUser_assignment().getTask_name());
			body_data.createCell(1).setCellValue(sd.getAssignment().getUser_assignment().getCode());
			body_data.createCell(2).setCellValue(sd.getId_owner().getFirstname() + " " + sd.getId_owner().getLastname());
			body_data.createCell(3).setCellValue(sd.getAssignment().getHourly_rate());
			body_data.createCell(4).setCellValue((float) new Methods().TimeConsume(sd.getTime_in(), sd.getTime_out())/60);
			body_data.createCell(5).setCellValue(0);
			row_body++;
		}
		
		row_body++;
	}
	
	private void userReportAggregatedUser(List<UserTask> result){
		int row_body = 3;
		
		for(UserTask sd:result){
			
			HSSFRow body_data = sheet.createRow(row_body);
			body_data.createCell(0).setCellValue(sd.getId_owner().getFirstname() + " " + sd.getId_owner().getLastname());
			body_data.createCell(1).setCellValue(sd.getAssignment().getUser_assignment().getTask_name());
			body_data.createCell(2).setCellValue(sd.getAssignment().getUser_assignment().getCode());
			body_data.createCell(3).setCellValue(sd.getAssignment().getHourly_rate());
			body_data.createCell(4).setCellValue((float) new Methods().TimeConsume(sd.getTime_in(), sd.getTime_out())/60);
			body_data.createCell(5).setCellValue(0);
			row_body++;
		}
		
		row_body++;
	}
	
	public void userReportDetaild(List<UserTask> result){
		
		int row_body = 3;
		
		for(UserTask sd:result){
			
			HSSFRow body_data = sheet.createRow(row_body);
			
			body_data.createCell(0).setCellValue(sd.getAssignment().getUser_assignment().getTask_name());
			body_data.createCell(1).setCellValue(""+sd.getDateCreated());
			body_data.createCell(2).setCellValue(sd.getId_owner().getFirstname() + " " + sd.getId_owner().getLastname());
			body_data.createCell(3).setCellValue(sd.getOwner_description());
			body_data.createCell(4).setCellValue(""+sd.getTime_in());
			body_data.createCell(5).setCellValue(""+sd.getTime_out());
			body_data.createCell(6).setCellValue((float) new Methods().TimeConsume(sd.getTime_in(), sd.getTime_out())/60);
			
			row_body++;
		}
		
		row_body++;
	}

public void userReport(List<UserTask> result){
		
		int row_body = 3;
		
		for(UserTask sd:result){
			
			HSSFRow body_data = sheet.createRow(row_body);
			
			body_data.createCell(0).setCellValue(sd.getAssignment().getUser_assignment().getTask_name());
			body_data.createCell(1).setCellValue(sd.getAssignment().getUser_assignment().getCode());
			body_data.createCell(2).setCellValue(sd.getId_owner().getFirstname() + " " + sd.getId_owner().getLastname());
			body_data.createCell(3).setCellValue(sd.getAssignment().getHourly_rate());
			body_data.createCell(4).setCellValue((float) new Methods().TimeConsume(sd.getTime_in(), sd.getTime_out())/60);
			
			row_body++;
		}
		
		row_body++;
	}
}
