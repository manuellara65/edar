package com.tocedar.project.controller;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tocedar.project.model.Departments;
import com.tocedar.project.model.User;
import com.tocedar.project.repositories.UserRepository;

@Controller
public class UserFilter {
	
	private UserRepository userRepo;
	
	@Autowired
	public void setUserRepo(UserRepository userRepo) {
		this.userRepo = userRepo;
	}

	@RequestMapping(value="/filter/{deptId}/{pos}",produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<User> usersFilter(@PathVariable int deptId,@PathVariable String pos){
		
		List<User> userFound = new ArrayList<>();
		
		System.out.println(deptId + " - " + pos);
		
		if(deptId<=0 && pos.equals("0")){
			userFound = (List<User>) userRepo.findAll();
		}else if(deptId>=1 && pos.equals("0")){
			userFound = userRepo.getUserListByDepartment(deptId);
		}else if(deptId<=0 && !pos.equals("0")){
			userFound = userRepo.getUserListByPosition(pos);
		}else if(deptId>=1 && !pos.equals("0")){
			userFound = userRepo.getUserListByDepartmentPosition(deptId, pos);
		}
		
		return userFound;
	}
	
	
	
}
