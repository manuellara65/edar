package com.tocedar.project.repositories;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import com.tocedar.project.model.Assignment;
import com.tocedar.project.model.Task;
import com.tocedar.project.model.User;
import com.tocedar.project.model.UserTask;

import java.util.Date;
import java.util.List;

@Transactional
public interface TaskRepository extends JpaRepository<Task,Integer> {
	
	/*@Query("SELECT Assignment.id,Task.name "
			+ "FROM Assignment "
			+ "LEFT join Task ON Assignment.task_id = Task.id_task "
			+ "WHERE Assignment.id_owner=?1")
	List<Object[]> getTaskNameList(int ownerId);*/
	
	//@Query("SELECT a.id,b.task_name,b.id_task FROM Assignment a,Task b WHERE a.task_id = b.id_task AND a.id_owner=?1")
	//List<Object[]> getTaskNameList(int ownerId);
	
	//@Query("UPDATE Task SET name = ?1 ,code = ?2, id_manager =?3, description = ?4, contact_person = ?5, default_task= ?6, billable = ?7,active = ?8,user_assigned=?9 WHERE id=?10")
	//@Modifying
	//int updateTask(String task_name,String code,int id_manager,String description,String contact_person,String default_task,String billable,String active,String user_assigned,int id);
	
	List<Task> findByActiveAndBillable(String active,String billable);
	
	List<Task> findByDescriptionContains(String description);
	
}
