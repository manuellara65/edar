package com.tocedar.project.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.tocedar.project.model.UserCredentials;

public interface UserCredentialRepository extends CrudRepository<UserCredentials,Integer>{

	public UserCredentials findByUsernameAndPassword(String username,String password);
	
	public UserCredentials findByUsername(String username);
	
	/*@Query("SELECT user_credential.id FROM UserCredentials AS user_credential WHERE user_credential.username = ?1")
	public Integer findOnlyIdByUsername(String username);*/
}
