package com.tocedar.project.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table(name="edr_sub_role")
//@IdClass(UserRoles.class)
@JsonIdentityInfo(generator=ObjectIdGenerators.IntSequenceGenerator.class,property="id_sub_role")
public class SubRole implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 */
	
	int id;
		
	@EmbeddedId
	SubRoleId sub_role_id;
	
	@MapsId("sub_role_id")
	UserRoles role;
	
	com.tocedar.project.model.User user1;
	
	public SubRole(){
		
	}
	
	@ManyToOne(cascade=CascadeType.DETACH,fetch=FetchType.EAGER)
	@JoinColumn(name="id_role",referencedColumnName="user_role_id",insertable=false,updatable=false)
	public UserRoles getRole() {
		return role;
	}
	public void setRole(UserRoles role) {
		this.role = role;
	}
	
	public SubRoleId getSub_role_id() {
		return sub_role_id;
	}
	public void setSub_role_id(SubRoleId sub_role_id) {
		this.sub_role_id = sub_role_id;
	}
	
	@JsonIgnore
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="id_user",insertable=false,updatable=false)
	public User getUser1() {
		return user1;
	}
	public void setUser1(com.tocedar.project.model.User user) {
		this.user1 = user;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
}
