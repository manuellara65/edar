package com.tocedar.project.service;

import com.tocedar.project.model.UserCredentials;

public interface UserService {

	void save(UserCredentials user);
	
	UserCredentials findByUsername(String username);
}
