package com.tocedar.project.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table(name="edr_assignment")
//@JsonIdentityInfo(generator=ObjectIdGenerators.IntSequenceGenerator.class,property="id_assignment")
public class Assignment {

	int id_assignment;
	
	Task user_assignment;
	
	User user_id;
	
	String assignment_type;
	
	Date start_date;
	
	Date end_date;
	
	String role_assignment;
	
	int hourly_rate;
	
	String active;
	
	int time_allot;
	
	int allowed_overrun;
	
	String notif_tm_overrun;
	
	
	public Assignment(User user_id){
		this.user_id = user_id;
	}
	
	public Assignment(Task task,User user,String assignment_type,Date start_date,Date end_date,int hourly_rate,String active,String notif_tm_overrun,int time_allot1,int allowed_overrun1){
		this.user_assignment = task;
		this.user_id = user;
		this.assignment_type = assignment_type;
		this.start_date = start_date;
		this.end_date = end_date;
		this.hourly_rate = hourly_rate;
		this.active = active;
		this.time_allot = time_allot1;
		this.allowed_overrun = allowed_overrun1;
		this.notif_tm_overrun = notif_tm_overrun;
	}
	
	public Assignment(){
		
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	public int getId_assignment() {
		return id_assignment;
	}
	public void setId_assignment(int id_assignment1) {
		this.id_assignment = id_assignment1;
	}

	@ManyToOne(cascade=CascadeType.DETACH)
	@JoinColumn(name="task_id")
	public Task getUser_assignment() {
		return user_assignment;
	}
	public void setUser_assignment(Task user_assignment) {
		this.user_assignment = user_assignment;
	}
	
	@ManyToOne(cascade=CascadeType.DETACH)
	@JoinColumn(name="user_id")
	@
	public User getUser_id() {
		return user_id;
	}
	public void setUser_id(User user_id) {
		this.user_id = user_id;
	}
	
	@Column(name="assignment_type")
	public String getAssignment_type() {
		return assignment_type;
	}
	public void setAssignment_type(String assignment_type) {
		this.assignment_type = assignment_type;
	}
	
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@Column(name="start_date",nullable=false)
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@Column(name="end_date",nullable=false)
	public Date getEnd_date() {
		return end_date;
	}
	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}
	
	@Column(name="role")
	public String getRole_assignment() {
		return role_assignment;
	}
	public void setRole_assignment(String role_assignment) {
		this.role_assignment = role_assignment;
	}
	
	@Column(name="hourly_rate")
	public int getHourly_rate() {
		return hourly_rate;
	}
	public void setHourly_rate(int hourly_rate) {
		this.hourly_rate = hourly_rate;
	}
	

	@Column(name="allowed_overrun")
	public int getAllowed_overrun() {
		return allowed_overrun;
	}

	public void setAllowed_overrun(int allowed_overrun) {
		this.allowed_overrun = allowed_overrun;
	}

	@Column(name="tm_overrun")
	public String getNotif_tm_overrun() {
		return notif_tm_overrun;
	}

	public void setNotif_tm_overrun(String notif_tm_overrun) {
		this.notif_tm_overrun = notif_tm_overrun;
	}

	@Column(name="alloted_time")
	public int getTime_allot() {
		return time_allot;
	}

	public void setTime_allot(int time_allot) {
		this.time_allot = time_allot;
	}
	
	@Column(name="active")
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "Assignment [id_assignment=" + id_assignment + ", user_assignment=" + user_assignment + ", user_id="
				+ user_id + ", assignment_type=" + assignment_type + ", start_date=" + start_date + ", end_date="
				+ end_date + ", role_assignment=" + role_assignment + ", hourly_rate=" + hourly_rate + ", active="
				+ active + ", time_allot=" + time_allot + ", allowed_overrun=" + allowed_overrun + ", notif_tm_overrun="
				+ notif_tm_overrun + "]";
	}
	
}
