package com.tocedar.project.service;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tocedar.project.model.SubRole;
import com.tocedar.project.model.UserCredentials;
import com.tocedar.project.model.UserRoles;
import com.tocedar.project.repositories.UserCredentialRepository;
import com.tocedar.project.repositories.UserRepository;

@Component
@Service
public class UserDetailsServiceImpl implements UserDetailsService{

	
	UserCredentialRepository userRepository;
	
	@Autowired
	public void setUserRepository(UserCredentialRepository userRepository) {
		this.userRepository = userRepository;
	}


	@Override
	@Transactional(readOnly=true)	
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		UserCredentials user = userRepository.findByUsername(username);
		
		Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
	
		//UserRoles role = user.getUser_info().getUser_role();
		
		for(SubRole s:user.getUser_info().getSubRole()){
			
			grantedAuthorities.add(new SimpleGrantedAuthority(s.getRole().getRole()));
			System.out.println("user role:"+s.getRole().getRole());
			
		}
		
		//grantedAuthorities.add(new SimpleGrantedAuthority(role.getRole()));
		
		return new org.springframework.security.core.userdetails.User(user.getUsername(),user.getPassword(),grantedAuthorities);
	}
	
	

}
