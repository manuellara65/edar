package com.tocedar.project.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.transaction.annotation.Transactional;

@Transactional
public class UserTaskDaoImpl {

	/* private String reportQueryName;
	  private int currentPage;
	  private int maxResults;
	  private int pageSize;
	  
	  public int getPageSize() {
	      return pageSize;
	  }
	  
	  public int getMaxPages() {
	      return maxResults / pageSize;
	  }

	  public void init(int pageSize, String countQueryName, 
	                   String reportQueryName) {
	      this.pageSize = pageSize;
	      this.reportQueryName = reportQueryName;
	      maxResults = ((Long) em.createNamedQuery(countQueryName)
	                                  .getSingleResult()).intValue();
	      currentPage = 0;
	  }
	  
	  public List getCurrentResults() {
	      return em.createNamedQuery(reportQueryName)
	               .setFirstResult(currentPage * pageSize)
	               .setMaxResults(pageSize)
	               .getResultList();
	  }
	  
	  public void next() {
	      currentPage++;
	  }
	  
	  public void previous() {
	      currentPage--;
	      if (currentPage < 0) {
	          currentPage = 0;
	      }
	  }
	  
	  public int getCurrentPage() {
	      return currentPage;
	  }
	  
	  public void setCurrentPage(int currentPage) {
	      this.currentPage = currentPage;
	  }
	
	@PersistenceContext
	private EntityManager em;*/
}
