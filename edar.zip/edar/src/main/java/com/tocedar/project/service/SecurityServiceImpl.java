package com.tocedar.project.service;

import java.util.Collection;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.tocedar.project.model.UserCredentials;
import com.tocedar.project.repositories.UserCredentialRepository;

@Component
@Service
public class SecurityServiceImpl implements SecurityService
{

	@Autowired
	private AuthenticationManager authenticationManager;
	
	private BCryptPasswordEncoder bcryptPasswordEncoder;
	
	@Autowired
	private UserCredentialRepository credentialRepository;
	
	@Autowired
	private UserDetailsService userDetailsService;
	
	private final Logger log = Logger.getLogger(SecurityServiceImpl.class);

	@Override
	public String findLoggedInUsername() {
		Object userDetails = SecurityContextHolder.getContext().getAuthentication().getDetails();
		if(userDetails instanceof UserDetails){
			return ((UserDetails) userDetails).getUsername();
		}
		return null;
	}

	@Override
	public UserCredentials autologin(String username, String password){
		
		/*UserCredentials userDetails = credentialRepository.findByUsernameAndPassword(username, password);
		
		System.out.println("userdetails:"+password);
		
        UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails, userDetails.getPassword(), (Collection) userDetails.getUser_info().getSubRole());

        authenticationManager.authenticate(usernamePasswordAuthenticationToken);
        
        usernamePasswordAuthenticationToken.getPrincipal();

        if (usernamePasswordAuthenticationToken.isAuthenticated()) {
            SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
            
           // UserCredentials uc = credentialRepository.findByUsername(userDetails.getUsername());
            
            //System.out.println("Login");
            
            return userDetails;
        }else{
        	return null;
        }*/
		
		    UserDetails userDetails = userDetailsService.loadUserByUsername(username);
		   
	        UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails, password, userDetails.getAuthorities());

	        authenticationManager.authenticate(usernamePasswordAuthenticationToken);
	        
	        if (usernamePasswordAuthenticationToken.isAuthenticated()) {
	            SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
	            
	            UserCredentials uc = credentialRepository.findByUsername(userDetails.getUsername());
	            
	            log.info("Authentication login: " + SecurityServiceImpl.class);
	            
	            return uc;
	        }else{
	        	return null;
	        }
	}

}
