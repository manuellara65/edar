package com.tocedar.project.model;

import java.util.List;

public class JsonResponse {

	int success;
	String action;
	List<UserTask> value;
	
	public int getSuccess() {
		return success;
	}
	public void setSuccess(int success) {
		this.success = success;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public List<UserTask> getValue() {
		return value;
	}
	public void setValue(List<UserTask> value) {
		this.value = value;
	}
	
	
}
