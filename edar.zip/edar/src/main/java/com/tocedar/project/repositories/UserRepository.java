package com.tocedar.project.repositories;


import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.tocedar.project.model.Departments;
import com.tocedar.project.model.User;
import com.tocedar.project.model.UserTask;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import java.lang.String;

@Transactional
@Repository
public interface UserRepository extends CrudRepository<User, Integer> {
	
	public User findById(int id);
	
	//@Query("FROM User AS user WHERE user.username=?1 AND user.password=?2")
	//public User findByUsernameAndPassword(String username,String password);
	
	//@Query("FROM User AS user WHERE user.username=?")
	//public User findByUsername(String username);
	
	/*@Query("SELECT a.id,a.firstname,a.lastname,a.email,c.role,a.status,b.department,a.department,a.username,b.id FROM User a,Departments b,UserRoles c WHERE a.department=b.id AND a.user_role_id=c.user_role_id")
	public List<User> userList();
	*/
	@PreAuthorize("hasAuthority('ADMIN')")
	@Modifying
	@Query("UPDATE User SET status=?1 WHERE id=?2")
	int updateStatus(int status,int id);
	
	@PreAuthorize("hasAuthority('ADMIN')")
	@Modifying
	@Query("UPDATE User SET department=?1,position=?2,firstname=?3,lastname=?4,email=?5,user_role_id=?6,status=?7 WHERE id=?8")
	int updateUserNoPassword(int department,String position,String firstname,String lastname,String email,int user_role_id,int status,int id);
	
	@PreAuthorize("hasAuthority('ADMIN')")
	@Modifying
	@Query("UPDATE User SET department=?1,position=?2,firstname=?3,lastname=?4,email=?5,user_role_id=?6,status=?7 WHERE id=?8")
	int updateUserWithPassword(int department,String position,String firstname,String lastname,String email,int user_role_id,int status,int id);
	
	//filter
	
	@Query("FROM User AS user where user.userDepartment.id=?1 AND user.position=?2")
	public List<User> getUserListByDepartmentPosition(int deptId,String pos);
	
	@Query("FROM User AS user WHERE user.position=?1")
	public List<User> getUserListByPosition(String pos);
	
	@Query("FROM User AS user WHERE user.userDepartment.id=?1")
	public List<User> getUserListByDepartment(int deptId);
	
	@Query("FROM User as user WHERE user.userDepartment.id IN (?1)")
	public List<User> getUserListMultipleDepartment(List<Integer> deptId);
	
	public List<User> findByStatus(int stat);
	
	List<User> findByFirstnameContainingOrLastnameContainingAndPositionEquals(String firstname,String lastname,String position);
	
	List<User> findByPosition(String position);
	
	List<User> findByUserDepartmentId(int deptId);
	
	List<User> findByUserDepartmentIdAndPosition(int dept,String pos);
	
	List<User> findByUserDepartmentIdAndPositionAndFirstnameContainingOrLastnameContaining(int dept,String pos,String fname,String lname);
	
	List<User> findByPositionAndFirstnameContainingOrLastname(String position,String lname,String fname);
	
	List<User> findByUserDepartmentIdAndFirstnameContainingOrLastname(int dept,String fname,String lname);
	
	List<User> findByUserDepartmentIdAndPositionAndLastnameContainingOrFirstnameContaining(int dept,String position,String lname,String fnam);
	
	List<User> findByPositionAndLastnameContainingAndFirstname(String position,String fname,String lname);
	
	List<User> findByUserDepartmentIdAndLastnameContainingAndFirstname(String position,String fname,String lname);
	
	List<User> findByLastnameContainingOrFirstnameContaining(String fname,String lname);
	
	//List<User> findByUser_dep
	
}
