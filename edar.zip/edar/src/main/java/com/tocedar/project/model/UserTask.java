package com.tocedar.project.model;

import java.sql.Time;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;

import com.tocedar.project.Methods;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table(name="edr_owner_task")
@JsonIdentityInfo(generator=ObjectIdGenerators.IntSequenceGenerator.class,property="@userTaskId")
public class UserTask {

	private int id;
	
	@NotNull
	private User id_owner;
	
	@NotEmpty
	private String owner_description;
	
	@NotNull
	private Time time_in;
	
	@NotNull
	private Time time_out;
	
	@NotNull
	private Date dateCreated;
	
	@NotNull
	private Assignment assignment;
	
	private float time_consumed;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getId() {
		return id;
	}

	public void setId(int id) {
		
		this.id = id;
	}

	@Column(name="timeIn")
	public Time getTime_in() {
		return time_in;
	}

	public void setTime_in(Time time_in) {
		this.time_in = time_in;
	}

	@Column(name="timeOut")
	public Time getTime_out() {
		return time_out;
	}

	public void setTime_out(Time time_out) {
		this.time_out = time_out;
	}

	@Column(name="owner_description")
	public String getOwner_description() {
		return owner_description;
	}

	public void setOwner_description(String owner_description) {
		this.owner_description = owner_description;
	}

	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@Column(name="date_created")
	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	
	@JsonView
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="id_owner")
	public User getId_owner() {
		return id_owner;
	}

	public void setId_owner(User id_owner1) {
		this.id_owner = id_owner1;
	}

	/*@JsonView
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name = "id_task",referencedColumnName="id")
	public Task getTask() {
		return task;
	}

	public void setTask(Task task1) {
		this.task = task1;
	}*/
	
	@JsonView
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name = "id_assignment")
	public Assignment getAssignment() {
		return assignment;
	}

	public void setAssignment(Assignment assignment) {
		this.assignment = assignment;
	}
	
	@Transient
	public float getTime_consumed() {
		Time tm_in = this.time_in;
		Time tm_out = this.time_out;
		
		return time_consumed = (float) new Methods().TimeConsume(tm_in, tm_out)/60;
	}

	public void setTime_consumed(float time_consumed) {
		this.time_consumed = time_consumed;
	}
	

//	@Override
//	public String toString() {
//		return "UserTask [id=" + id + ", id_owner=" + id_owner + ", owner_description=" + owner_description
//				+ ", time_in=" + time_in + ", time_out=" + time_out + ", dateCreated=" + dateCreated + ", assignment="
//				+ assignment + ", deleted=" + deleted + "]";
//	}

}
