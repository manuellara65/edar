package com.tocedar.project.service;

import com.tocedar.project.model.UserCredentials;

public interface SecurityService {

	public String findLoggedInUsername();
	
	public UserCredentials autologin(String username,String password);
}
