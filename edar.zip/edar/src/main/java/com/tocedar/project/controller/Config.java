package com.tocedar.project.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tocedar.project.model.Assignment;

@Controller
public class Config {
	
	@RequestMapping(value="/admin/configurations")
	public String index(Model model){
		return "manage/configuration";
	}

}
