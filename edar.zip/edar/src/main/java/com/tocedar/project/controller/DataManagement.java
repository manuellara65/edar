package com.tocedar.project.controller;

import java.io.IOException;
import java.net.MalformedURLException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tocedar.project.Methods;
import com.tocedar.project.model.JsonResponse;
import com.tocedar.project.model.User;
import com.tocedar.project.model.UserTask;
import com.tocedar.project.repositories.UserRepository;
import com.tocedar.project.repositories.DepartmentRepository;
import com.tocedar.project.repositories.TaskRepository;
import com.tocedar.project.repositories.UserTaskRepository;

@Controller
public class DataManagement {
	
	Logger log4 = Logger.getLogger(DataManagement.class);

	private UserRepository userRepository;
	private TaskRepository taskRepo;
	private UserTaskRepository userTaskRepo;
	private DepartmentRepository deptRepo;

	@Autowired
	public void setTaskRepo(TaskRepository taskRepo) {
		this.taskRepo = taskRepo;
	}
	
	@Autowired
	public void setUserTaskRepo(UserTaskRepository userTaskRepo) {
		this.userTaskRepo = userTaskRepo;
	}
	
	@Autowired
	public void setUserRepository(UserRepository userReposit) {
		this.userRepository = userReposit;
	}
	
	@Autowired
	public void setDeptRepo(DepartmentRepository deptRepo) {
		this.deptRepo = deptRepo;
	}

	/* start of user management */
	
	/*@RequestMapping(value="/addUser",method=RequestMethod.GET)
	public @ResponseBody boolean saveUser(User user,HttpSession session) throws ParseException{
				
		if(userRepository.isUsernameExist(user.getUsername()) == null){
			user.setCreated_by_id(Integer.parseInt(session.getAttribute("userId").toString()));
			user.setDate_created(new Methods().getDateNow("yyyy-MM-dd"));
			
			userRepository.save(user);
			
			return true;
		}else{
			return false;
		}
	}*/
	
	@RequestMapping(value="/deleteTask/delete/{id}")
	public String deleteTask(@PathVariable Integer id){
		
		taskRepo.delete(id);
		return "redirect:/task";
	}
	
	@RequestMapping(value="/deleteUser/delete/{id}")
	public String deleteUser(@PathVariable Integer id){
		
		userRepository.delete(id);
		return "redirect:/main";
	}
	
	/*@RequestMapping(value="/activation/{stat}/{id}")
	public String editUserStat(@PathVariable int stat,@PathVariable int id){
		
		userRepository.updateStatus(stat, id);
		
		return "redirect:/main";
	}*/
	
	@RequestMapping(value="/updateUserNow/update/{isChangePass}")
	public @ResponseBody int updateUser(@PathVariable String isChangePass,User user){
		if(isChangePass == "noPassword"){
			//return  userRepository.updateUserNoPassword(user.getDepartment(), user.getPosition(), user.getFirstname(), user.getLastname(), user.getEmail(), user.getUsername(),user.getUser_role_id(), user.getStatus(), user.getId());
		}else{
			//return userRepository.updateUserWithPassword(user.getDepartment(), user.getPosition(), user.getFirstname(), user.getLastname(), user.getEmail(), user.getUsername(),user.getPassword(),user.getUser_role_id(), user.getStatus(), user.getId());
		}return 0;
	}
	
	/* end of user management */
		
	@RequestMapping(value="/createUserTask",produces=MediaType.APPLICATION_JSON_VALUE)
	public String createSprint1(UserTask userTask,HttpSession session) throws IOException {
		
		int userId = Integer.parseInt(session.getAttribute("userId").toString());
		userTaskRepo.save(userTask);
		
		return "redirect:/getSprintList/"+userTask.getId_owner()+"";
	}

	/*@RequestMapping(value="/getSprintList/{id}",produces=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<UserTask> getTaskListUsingSprint(@PathVariable int id,UserTask user){
		return userTaskRepo.getMyTaskList(id);  //get user task list
	}*/
	
	@RequestMapping(value="/getTaskInfo/{id}",produces=MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody UserTask getUserTaskInfo(@PathVariable int id,UserTask user){
		
		/*UserTask userJson = userTaskRepo.findOne(id);
		
		user.setId_owned_sprint(userJson.getId_owned_sprint());
		user.setOwner_description(userJson.getOwner_description());
		user.setTime_in(userJson.getTime_in());
		user.setTime_out(userJson.getTime_out());
		user.setId_task(userJson.getId_task());
		user.setId(userJson.getId());
		*/
		
		return user;
	}
	
	/*@RequestMapping(value="/editThisTask/{idTaskToUpdate}",produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody JsonResponse updateTask(@PathVariable int idTaskToUpdate,UserTask user) throws MalformedURLException{
		
		int thisTaskUptate = userTaskRepo.isUpdated(user.getId_task(), user.getOwner_description(), user.getTime_in(), user.getTime_out(),idTaskToUpdate);
		
		System.out.println("owner"+user.getId_owner());
		
		JsonResponse json = new JsonResponse();
		json.setSuccess(thisTaskUptate);
		json.setAction("Edit");
		json.setValue(getTaskListUsingSprint(user.getId_owner(),user));
		
		return json;
	}*/
	
	
	
}
