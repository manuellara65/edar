package com.tocedar.project.controller;

import java.math.BigDecimal;
import java.sql.Time;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tocedar.project.Methods;
import com.tocedar.project.model.Assignment;
import com.tocedar.project.model.MyTask;
import com.tocedar.project.model.Task;
import com.tocedar.project.model.User;
import com.tocedar.project.model.UserTask;
import com.tocedar.project.repositories.AssignmentRepository;
import com.tocedar.project.repositories.DepartmentRepository;
import com.tocedar.project.repositories.UserRepository;
import com.tocedar.project.repositories.UserTaskRepository;
import com.tocedar.project.repositories.TaskRepository;

@Controller
public class WebController {
	
	private TaskRepository repository;
	private UserRepository userRepository;
	private DepartmentRepository deptRepo;
	private UserTaskRepository userTaskRepo;
	private AssignmentRepository assignmentRepo;
	private int userId;

	@Autowired
	public void setUserTaskRepo(UserTaskRepository userTaskRepo) {
		this.userTaskRepo = userTaskRepo;
	}

	@Autowired
	public void setDeptRepo(DepartmentRepository deptRepo) {
		this.deptRepo = deptRepo;
	}

	@Autowired
	public void setEdarRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Autowired
	public void setRepository(TaskRepository repository) {
		this.repository = repository;
	}
	
	
	@Autowired
	public void setAssignmentRepo(AssignmentRepository assignmentRepo) {
		this.assignmentRepo = assignmentRepo;
	}

	@RequestMapping(value="/main")
	public String index(Model model,HttpSession session){
		
		String[] month = {"January","February","March","April","May","June","July","August","September","October","November","December"};
		int[] year = new int[100];
		String[] time_hour = new String[24];
		String[] time_min = new String[60];
		
		int x1 = 2000;
		for(int x=0;x<=99;x++){
			year[x] = x1++;
		}
		for(int th=0;th<24;th++){
			time_hour[th] = (th<=9) ? "0"+th : ""+th;
		}
		for(int tm=0;tm<60;tm++){
			time_min[tm] = (tm<=9) ? "0"+tm :""+tm;
		}
		
		//System.out.println("userId:"+Integer.parseInt(session.getAttribute("userId").toString()));
		
		userId =Integer.parseInt(session.getAttribute("userId").toString());
		
		System.out.println("userId:"+userId);
		
		List<Assignment> assignedTask = assignmentRepo.assignedTask(new User(userId));
		
		model.addAttribute("month",month);
		model.addAttribute("year",year);
		model.addAttribute("time_hour",time_hour);
		model.addAttribute("time_minute",time_min);
		model.addAttribute("assignedTask",assignedTask);
		model.addAttribute("taskObject",new UserTask());
		
		return "index";
	}
	
	@RequestMapping(value={"/calendar","/calendar/{month1}/{year}"})
	public @ResponseBody String calendar(@PathVariable int month1,@PathVariable int year,HttpSession session) throws ParseException{
		
		Calendar now = Calendar.getInstance();
		
		String todayIndicator="";
		
		int mn = 0;
		int year1 = Calendar.YEAR;
		
		if(month1 == 0 && year == 0){
			
			mn = now.get(Calendar.MONTH)+1;
			year1 = now.get(Calendar.YEAR);
			
		}else{
			
			mn = month1;
			year1 = year;
			
		}
		
		LocalDate date = LocalDate.of(year1, Month.of(mn) , 1);
		int month = date.getMonthValue();
		
		LocalDate endOfMonth = date.withDayOfMonth(date.lengthOfMonth()).plusDays(1);
		
		while (date.getDayOfWeek() != DayOfWeek.SUNDAY) {
		    date = date.minusDays(1);
		}
		
		DateFormat format = new SimpleDateFormat("yyyy-MM-d");
		String from1 = year1+"-"+mn+"-1";
		String to1 = year1+"-"+mn+"-31";
		
		Date from = format.parse(from1);
		Date to = format.parse(to1);
		
		List<UserTask> userTaskBetweenDates = userTaskRepo.findBetweenDates(new User(userId), from, to);
		
		String cal = "<table class='table table-bordered table-hover' id='tblCalendar'>"
						+ "<thead>"
							+ "<tr>"
								+ "<th colspan='7'><center>" + Month.of(mn) + " " + year1 + "</center></th>"
							+ "</tr>"
						+ "</thead>"
						+ "<thead>"
							+ "<tr>"
								+ "<th><a href='#'>Sun</a></th>"
								+ "<th>Mon</th>"
								+ "<th>Tue</th>"
								+ "<th>Wed</th>"
								+ "<th>Thu</th>"
								+ "<th>Fri</th>"
								+ "<th>Sat</th>"
							+ "</tr>"
						+ "</thead>";
		
		int ctr=0;
		int total_task = 0;
		String div="";
		int time_consumed=0;
							
		while (date.isBefore(endOfMonth)) {

			cal+="<tr id='1' value='"+date+"'>";
			
		    StringBuilder row = new StringBuilder(7 * 4);
		    
		    for (int index = 0; index < 7; index++) {
		    	
		        if (month == date.getMonthValue()) {
		        	
		        	int day = date.getDayOfMonth();
		        	if(day == now.get(Calendar.DAY_OF_MONTH) && month == now.get(Calendar.MONTH)+1 && year1 == now.get(Calendar.YEAR))
		        	{
		        		todayIndicator = "style='background-color:#e6e6ff'";
		        	}else{
		        		todayIndicator = "";
		        	}
		        	
		        	for(int c=ctr;c<=userTaskBetweenDates.size()-1;c++){
		        		LocalDate date_created = LocalDate.parse(userTaskBetweenDates.get(c).getDateCreated().toString());
		    			if(date_created.getDayOfMonth() == day){
		    				total_task++;
		    				time_consumed+=new Methods().TimeConsume(userTaskBetweenDates.get(c).getTime_in(),userTaskBetweenDates.get(c).getTime_out());
		    			}else{
		    				ctr=c;
		    				break;
		    			}
		    		}
		        	
		        	if(total_task>0){
		        		div = "<div class='drop-shadow-content'>"
		        					+ "<span>Total Task: "+total_task+"</span><br/>"
		        					+ "<span>Consumed: "+time_consumed/60+" hrs and " + time_consumed%60 + " min(s).</span>"
		        				+ "</div>";
		        	}else{
		        		div="";
		        	}
		            
		        	row.append("<td "+ todayIndicator +">" + day + div + "</td>");
		        	
		        	total_task=0;
		        	time_consumed=0;
		            
		        } else {
		            row.append("<td style='background-color:#c0c0c0;opacity:0.5'>" + date.getDayOfMonth() + "</td>");
		        }
		        
		        date = date.plusDays(1);
		    }
		    
		    cal+=row+"</tr>\n";
		    
		}
		
		cal+="</table>";
		
		return cal;
	}
	
	@RequestMapping(value="/user/createTaskWeekly/{startDate}")
	public @ResponseBody String weeklyTask(@PathVariable String startDate,HttpSession session,User id) throws ParseException{
		
		//Integer userId = Integer.parseInt(session.getAttribute("userId").toString());
		
		LocalDate locl = LocalDate.parse(startDate);
		
		LocalDate local = LocalDate.of(locl.getYear(), locl.getMonth(), locl.getDayOfMonth());
		StringBuilder builder = new StringBuilder(7);
		
		String[] days = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
		
		LocalDate[] date = new LocalDate[8]; 
		Date[] localDateToDate = new Date[8];
		
		String byWeek="";
		String listMyTask="";
		String timeConsumed="";
		
		//weekly
		for(int x=0;x<=6;x++){
			
			date[x] = local;
			java.util.Date dates = java.sql.Date.valueOf(date[x]);
			
			byWeek += "<th id='" + days[x] + "' value='" + dates + "'>" + days[x] + " <span class='pull-right'>"+local.getDayOfMonth() +"</span> </th>";
			
			localDateToDate[x] = java.sql.Date.valueOf(date[x]);
			
			local = local.plusDays(1);
			
		}
		
		List<UserTask> result = userTaskRepo.findByDateCreated(localDateToDate[0], localDateToDate[1],localDateToDate[2],localDateToDate[3],localDateToDate[4],localDateToDate[5],localDateToDate[6],new User(userId));
		
		DayOfWeek[] dow = {DayOfWeek.SUNDAY,DayOfWeek.MONDAY,DayOfWeek.TUESDAY,DayOfWeek.WEDNESDAY,DayOfWeek.THURSDAY,DayOfWeek.FRIDAY,DayOfWeek.SATURDAY};
		
		if(result.size()>=1)
		{
			String[][] info_description = new String[7][result.size()];
			String[][] info_task_name = new String[7][result.size()];
			Time[][] info_time_in = new Time[7][result.size()];
			Time[][] info_time_out = new Time[7][result.size()];
			int[][] info_id = new int[7][result.size()];
			
			int consume_time=0;
			
			int sun=0,mon=0,tue=0,wed=0,thu=0,fri=0,sat=0;
			
			for(UserTask users:result){
				
				LocalDate local1  = LocalDate.parse(users.getDateCreated().toString());
				
				LocalDate lcl = LocalDate.of(local1.getYear(), local1.getMonth(), local1.getDayOfMonth());
				
				if(lcl.getDayOfWeek() == DayOfWeek.SUNDAY){
					info_description[0][sun] = users.getOwner_description();
					info_task_name[0][sun] = users.getAssignment().getUser_assignment().getTask_name();
					info_time_in[0][sun] = users.getTime_in();
					info_time_out[0][sun] = users.getTime_out();
					info_id[0][sun] = users.getId();
					sun++;
				}
				if(lcl.getDayOfWeek() == DayOfWeek.MONDAY){
					info_description[1][mon] = users.getOwner_description();
					info_task_name[1][mon] = users.getAssignment().getUser_assignment().getTask_name();
					info_time_in[1][mon] = users.getTime_in();
					info_time_out[1][mon] = users.getTime_out();
					info_id[1][mon] = users.getId();
					mon++;
				}
				if(lcl.getDayOfWeek() == DayOfWeek.TUESDAY){
					info_description[2][tue] = users.getOwner_description();
					info_task_name[2][tue] = users.getAssignment().getUser_assignment().getTask_name();
					info_time_in[2][tue] = users.getTime_in();
					info_time_out[2][tue] = users.getTime_out();
					info_id[2][tue] = users.getId();
					tue++;
				}
				if(lcl.getDayOfWeek() == DayOfWeek.WEDNESDAY){
					info_description[3][wed] = users.getOwner_description();
					info_task_name[3][wed] = users.getAssignment().getUser_assignment().getTask_name();
					info_time_in[3][wed] = users.getTime_in();
					info_time_out[3][wed] = users.getTime_out();
					info_id[3][wed] = users.getId();
					wed++;
				}
				if(lcl.getDayOfWeek() == DayOfWeek.THURSDAY){
					info_description[4][thu] = users.getOwner_description();
					info_task_name[4][thu] = users.getAssignment().getUser_assignment().getTask_name();
					info_time_in[4][thu] = users.getTime_in();
					info_time_out[4][thu] = users.getTime_out();
					info_id[4][thu] = users.getId();
					thu++;
				}
				if(lcl.getDayOfWeek() == DayOfWeek.FRIDAY){
					info_description[5][fri] = users.getOwner_description();
					info_task_name[5][fri] = users.getAssignment().getUser_assignment().getTask_name();
					info_time_in[5][fri] = users.getTime_in();
					info_time_out[5][fri] = users.getTime_out();
					info_id[5][fri] = users.getId();
					fri++;
				}if(lcl.getDayOfWeek() == DayOfWeek.SATURDAY){
					info_description[6][sat] = users.getOwner_description();
					info_task_name[6][sat] = users.getAssignment().getUser_assignment().getTask_name();
					info_time_in[6][sat] = users.getTime_in();
					info_time_out[6][sat] = users.getTime_out();
					info_id[6][sat] = users.getId();
					sat++;
				}
			}
			//week row
			for(int index=0;index<=6;index++)
				{
					consume_time = 0;
					listMyTask+="<td class='"+ days[index] +"'>";
					
						for(int ind=0;ind<info_description[index].length;ind++)
						{
							
							if(info_description[index][ind] == null){
								break;
							}
													
							String edit = "edit("+info_id[index][ind]+",\"" + days[index] + "\")";
							
							listMyTask+="<div class='drop-shadow' id='parent_" + info_id[index][ind] + "' style='background-color:#4dd2ff;line-height:15px'>"
											+"<button type='button' id='" + info_id[index][ind] + "' value='" + info_id[index][ind] + "' class='btn btn-link pull-right' onclick='"+edit+"'><span class='glyphicon glyphicon-edit' ></span></button>"
											+"<h4 id='name_"+info_id[index][ind]+"'>"+ info_task_name[index][ind] +"</h4>"
											+"<div style='font-size:11px'>"
											+ "<span id='des_"+info_id[index][ind]+"'>Description: " + info_description[index][ind]  + "</span><br/>"
											+"<span id='time_in_"+info_id[index][ind]+"'>Time in: " + info_time_in[index][ind] + "</span><br/>"
											+"<span id='time_out_"+info_id[index][ind]+"'>Time out: " + info_time_out[index][ind] +"</span></div>"
											+"</div><br/>";
							
							consume_time += new Methods().TimeConsume(info_time_in[index][ind],info_time_out[index][ind]);
						}
						
					listMyTask+="</td>";
					if(consume_time>0){	
						timeConsumed += "<td>Consumed: <span class='consumed_time_word_"+days[index]+"'>" + consume_time/60 + " hrs and " + consume_time%60 + " mins.</span><input type='hidden' id='consumed_time_" + days[index] + "' value='" + consume_time + "'></td>";
					}else{
						timeConsumed += "<td>Consumed: <span class='consumed_time_word_"+days[index]+"'></span><input type='hidden' id='consumed_time_" + days[index] + "' value='0'></td>";
					}
				}
		}else{
			for(int index=0;index<=6;index++){
				listMyTask += "<td class='"+ days[index] +"'>Consumed: <span class='consumed_time_word_"+days[index]+"'></span><input type='hidden' id='consumed_time_" + days[index] + "' value='0'></td>";
			}
		}
		
		builder.append("<table id='tblAddTask' class='table table-bordered table-responsive'>"
				+ "<thead>"
					+ "<tr>"
						+ "<th colspan='7'><button type='button' id='btnBackToCalendar' class='btn btn-default pull-left'><span class='glyphicon glyphicon-chevron-left'></span></button><center>" + date[0].getMonth() + " " + date[0].getDayOfMonth() + " - "+ date[6].getMonth() + " " + date[6].getDayOfMonth()+" " + date[6].getYear() +"</center></th>"
					+ "</tr>"
				+ "</thead>"
				+ "<thead class='next_row'>"
					+ "<tr>" + byWeek + "</tr>"
				+ "</thead>" //end of head
				+ "<tbody>"
					+ "<tr>" + timeConsumed + "</tr>"
					+ "<tr>" + listMyTask + "</tr>"
				+ "</tbody>"
				+ "</table>");
		
		return  builder.toString();
	}
	
	@RequestMapping(value="/manage")
	public String ProposedTask(Model model){
		return "redirect:/admin/users";
	}
	
	@RequestMapping(value="/user/myTask")
	public String userTask(Model model,HttpSession session){
		String[] month = {"January","February","March","April","May","June","July","August","September","November","December"};
		int[] day = new int[32];
		String[] time_hour = new String[24];
		String[] time_min = new String[60];
		
		for(int num=0;num<=23;num++){
			time_hour[num] = (num<=9) ? "0"+num : ""+num;
		}
		for(int num=0;num<=59;num++){
			time_min[num] = (num<=9) ? "0"+num : ""+num;
		}
		for(int d=1;d<=31;d++){
			day[d] = d;
		}
		
		model.addAttribute("task",new UserTask());
		model.addAttribute("taskList",repository.findAll());
		model.addAttribute("month",month);
		model.addAttribute("day",day);
		model.addAttribute("time_hour",time_hour);
		model.addAttribute("time_min",time_min);
		
		return "myTask";
	}
}