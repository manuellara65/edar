package com.tocedar.project.validation;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.validation.executable.ExecutableValidator;
import javax.validation.metadata.BeanDescriptor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;

import com.tocedar.project.model.User;
import com.tocedar.project.model.UserCredentials;
import com.tocedar.project.repositories.UserCredentialRepository;

public class FieldValidator implements Validator{

	private UserCredentialRepository credentialRepository;
	
	@Autowired
	public void setCredentialRepository(UserCredentialRepository credentialRepository) {
		this.credentialRepository = credentialRepository;
	}

	public void validateUsername(Object obj,Errors errors){
		
		
		
	}
	
	public void validatePassword(Object obj,Errors errors){
		ValidationUtils.rejectIfEmpty(errors, "user_cred.password", "passwordRequired","Password must not empty");
		UserCredentials user = (UserCredentials) obj;
		if(!user.getPassword().equals(user.getConfirmPassword())){
			errors.rejectValue("user_cred.confirmPassword", "confirmPassword","Confirm Password is not equal to Password!");
		}
		
	}
	
	public void validateDateRange(Object obj,Errors errors){
		ValidationUtils.rejectIfEmpty(errors, "from", "requiredField","Required Field!");
	}
	
	@Override
	public ExecutableValidator forExecutables() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BeanDescriptor getConstraintsForClass(Class<?> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> T unwrap(Class<T> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> Set<ConstraintViolation<T>> validate(T arg0, Class<?>... arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> Set<ConstraintViolation<T>> validateProperty(T arg0, String arg1, Class<?>... arg2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> Set<ConstraintViolation<T>> validateValue(Class<T> arg0, String arg1, Object arg2, Class<?>... arg3) {
		// TODO Auto-generated method stub
		return null;
	}

}
