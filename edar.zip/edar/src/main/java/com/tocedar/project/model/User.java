package com.tocedar.project.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.tocedar.project.Methods;
import com.tocedar.project.model.SubRole;

@Entity
@Table(name="edr_users_info")
//@JsonIdentityInfo(generator=ObjectIdGenerators.IntSequenceGenerator.class,property="@userId")
public class User{
	
	/**
	 * 
	 */
//	private static final long serialVersionUID = 1L;
	
	private int id;
	//@NotNull(message="Please select user type!")
	//private UserRoles user_role;
	
	private List<UserTask> userTask;
	
	private List<Assignment> userAssignment;
	
	@NotEmpty
	private String firstname;
	
	@NotEmpty
	private String lastname;
	
	@NotEmpty
	private String position;
	
	@NotEmpty
	@Email
	private String email;
	
	@NotNull
	private int status;
	
	private Date date_created = new Methods().getDateNow("yyyy-MM-dd");
	
	@NotNull
	private Departments userDepartment;
	
	private UserCredentials user_cred;
	
	//private List<String> role;
	
	//private SubRole sub_role;
		
	@NotNull(message="Please select role(s)!")
	private List<SubRole> subRole;
	
	public User(/*UserRoles user_role*/String firstname,String lastname,String position,String email,int status,Date date_created,Departments dept){
		
		//this.user_role = user_role;
		this.firstname = firstname;
		this.lastname = lastname;
		this.position = position;
		this.email = email;
		this.status = status;
		this.date_created = date_created;
		this.userDepartment = dept;
	}
	
	public User(){
		
	}
	
	public User(int id2){
		//this.emp_id = id2;
		this.id = id2;
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="user_id")
	@JsonView
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@JsonView
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	
	
	@JsonView
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	
	@JsonView
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	
	@JsonView
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@JsonView
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	public Date getDate_created() {
		return date_created;
	}
	public void setDate_created(Date date_created) {
		this.date_created = date_created;
	}
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="department",nullable=true)
	public Departments getUserDepartment() {
		return userDepartment;
	}

	public void setUserDepartment(Departments userDepartment) {
		this.userDepartment = userDepartment;
	}

	@JsonView
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}

	/*@JsonView
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="user_role_id",nullable=true)
	public UserRoles getUser_role() {
		return user_role;
	}
	public void setUser_role(UserRoles user_role1) {
		this.user_role = user_role1;
	}*/
	
	@JsonIgnore
	@OneToMany(cascade=CascadeType.DETACH,
			fetch=FetchType.EAGER,
			mappedBy="id_owner")
	public List<UserTask> getUserTask() {
		return userTask;
	}
	public void setUserTask(List<UserTask> userTask) {
		this.userTask = userTask;
	}
	
	@JsonIgnore
	@OneToMany(cascade=CascadeType.DETACH,
			mappedBy="user_id")
	public List<Assignment> getUserAssignment() {
		return userAssignment;
	}
	public void setUserAssignment(List<Assignment> userAssignment) {
		this.userAssignment = userAssignment;
	}

	//@JsonIgnore
	@OneToOne(cascade=CascadeType.ALL,mappedBy="user_info")
	public UserCredentials getUser_cred() {
		return user_cred;
	}

	public void setUser_cred(UserCredentials user_cred) {
		this.user_cred = user_cred;
	}

	//@JsonIgnore
	@OneToMany(cascade=CascadeType.DETACH,
			mappedBy="user1")
	public List<SubRole> getSubRole() {
		return subRole;
	}

	public void setSubRole(List<SubRole> subRole) {
		this.subRole = subRole;
	}

	
	/*@OneToOne(cascade=CascadeType.ALL,mappedBy="sub_role_id")
	public SubRole getSub_role() {
		return sub_role;
	}

	public void setSub_role(SubRole sub_role) {
		this.sub_role = sub_role;
	}*/
	
	/*@Column(name="role")
	public List<String> getRole() {
		return role;
	}

	public void setRole(List<String> role) {
		this.role = role;
	}*/
	
//	@Override
//	public String toString() {
//		return "User [id=" + id + ", created_by_id=" + created_by_id + ", user_role=" + user_role + ", userTask="
//				+ userTask + ", userAssignment=" + userAssignment + ", firstname=" + firstname + ", lastname="
//				+ lastname + ", position=" + position + ", email=" + email + ", status=" + status + ", date_created="
//				+ date_created + ", user_department=" + user_department + ", user_cred=" + user_cred + "]";
//	}
	

	
	
}
