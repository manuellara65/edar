package com.tocedar.project.controller;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.tocedar.project.generatereport.ExcelView;
import com.tocedar.project.model.Assignment;
import com.tocedar.project.model.CreateReport;
import com.tocedar.project.model.SubRole;
import com.tocedar.project.model.User;
import com.tocedar.project.model.UserTask;
import com.tocedar.project.repositories.AssignmentRepository;
import com.tocedar.project.repositories.TaskRepository;
import com.tocedar.project.repositories.UserRepository;
import com.tocedar.project.repositories.UserTaskRepository;
import com.tocedar.project.validation.FieldValidator;

@Validated
@Controller
@RequestMapping("/report")
public class Reporting {
	
	DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
	private AssignmentRepository assignmentRepository;
	
	@Autowired private UserTaskRepository userTaskRepo;
	
	@Autowired
	public void setAssignmentRepository(AssignmentRepository assignmentRepository) {
		this.assignmentRepository = assignmentRepository;
	}

	int userId;
	
	@RequestMapping(value="/user-reporting")
	public String reportingUser(Model model,HttpSession session){
		
		int userId = Integer.parseInt(session.getAttribute("userId").toString());
		
		model.addAttribute("myAssignedTask",assignmentRepository.assignedTask(new User(userId)));
		model.addAttribute("genReport",new CreateReport());
		
		//for(Assignment s : assignmentRepository.assignedTask(new User(userId))){
			
			//System.out.println("Id:"+s.getUser_id().getId() +"-");
			
				//for(SubRole sd:s.getUser_id().getSubRole()){
				//	System.out.println("role:"+sd.getRole().getRole());
				//}
		//}
		
		return "Reporting/user-reporting";
	}
	
	@RequestMapping(value="/global-reporting")
	public String reportingGlobal(Model model,HttpSession session){
		
		//userId = Integer.parseInt(session.getAttribute("userId").toString());
		//model.addAttribute("myAssignedTask",assignmentRepository.assignedTask(new User(userId)));
		
		model.addAttribute("genReport",new CreateReport());
	
		return "Reporting/global-reporting";
	}
	
	
	
	@RequestMapping(value={"/reporting/{orderBy}","/reporting"},produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String,Object> reporting(	CreateReport createReport,
														Model model,
														Errors errors,
														BindingResult result,
														@PathVariable("orderBy") Optional<String> order,
														@RequestParam(value="page",required=false) Integer page1
														
													) throws ParseException{
		
		Map<String,Object> ls = new HashMap<>();
		
		//FieldValidator validate = new FieldValidator();
		//validate.validateDateRange(createReport.getFrom_dt(), errors);
		
		ValidationUtils.rejectIfEmpty(errors, "from_dt", "RequiredField","Missing field!");
		ValidationUtils.rejectIfEmpty(errors, "until_dt", "RequiredField","Missing field!");
		ValidationUtils.rejectIfEmpty(errors, "taskList", "RequiredField","Missing/Empty field!");
		ValidationUtils.rejectIfEmpty(errors, "deptList", "RequiredField","Missing/Empty field!");
		
		
		if(result.hasErrors()){
			ls.put("error", result.getAllErrors());
		}else{
			Date from_date = createReport.getFrom_dt();
			Date until_date = createReport.getUntil_dt();
			
			Page<UserTask> userTaskLst = null;
			
			List<UserTask> userTaskLst1 = null;
			
			if(order.isPresent()){
				
				if(order.get().toString().equals("task")){	
					
					PageRequest pageByTask = new PageRequest(page1,10,Sort.Direction.ASC,"assignment.user_assignment.task_name");
					
					userTaskLst = userTaskRepo.findUserTaskGloballyDetail(from_date, until_date,createReport.getTaskList(),createReport.getDeptList(),createReport.getUserList(),pageByTask);
					
					userTaskLst1 = userTaskLst.getContent();
					
				}else{
					
					System.out.println("Order by user");
					
					System.out.println("order by:"+page1);
					
					PageRequest pageByUser = new PageRequest(page1,10,Sort.Direction.ASC,"id_owner.lastname");
					
					userTaskLst = userTaskRepo.findUserTaskGloballyDetail(from_date, until_date, createReport.getTaskList(), createReport.getDeptList(), createReport.getUserList(),pageByUser);
					
					System.out.println("from_data"+from_date);
					System.out.println("until_date"+until_date);
					System.out.println("createReport task"+createReport.getTaskList());
					System.out.println("createReport dept"+createReport.getDeptList());
					
					userTaskLst1 = userTaskLst.getContent();
				}
				
			}else{
				
			}
			

			ls.put("success", userTaskLst1);
			ls.put("page",userTaskLst.getTotalPages());
		}
		
		
		return ls;
		
	}
	
	@RequestMapping(value="/generateAggregateReport/{from_dt}/{until_dt}/{taskList}/{departmentList}/{userList}/{order}")
	public ModelAndView generateExcelAggregateReport(HttpServletResponse response,
												@PathVariable(value="from_dt") String from,
												@PathVariable(value="until_dt") String until,
												@PathVariable(value="taskList") List<Integer> taskId,
												@PathVariable("departmentList") List<Integer> deptId,
												@PathVariable("userList") List<Integer> userId,
												@PathVariable("order") String order
												) throws ParseException{
		
		Map<String,Object> model = new HashMap<String,Object>();
		
		model.put("sheetname", "Aggregated " + order + " Reports");
		
		Date from1 = format1.parse(from);
		Date until1 = format1.parse(until);
		
		List<Date> range = new ArrayList<Date>();
		range.add(from1);
		range.add(until1);
		
		model.put("dateRange",range);
		
		List<String> header = new ArrayList<String>();
		
		if(order.equals("task")){
			header.add("Task name");
			header.add("Task code");
			header.add("User");
			
			Sort sort_by_task = new Sort(Sort.Direction.ASC,"assignment.user_assignment.task_name");
			List<UserTask> userTask = userTaskRepo.findUserTaskGloballyDetail(from1, until1,taskId,deptId,userId,sort_by_task);
			
			model.put("results",userTask);
			model.put("category", 2);
		}else{
			header.add("User");
			header.add("Task");
			header.add("Task code");
			
			Sort sort_by_name = new Sort(Sort.Direction.ASC,"id_owner.lastname");
			List<UserTask> userTask = userTaskRepo.findUserTaskGloballyDetail(from1, until1,taskId,deptId,userId,sort_by_name);
			model.put("results",userTask);
			model.put("category", 3);
		}
		
		header.add("Rate");
		header.add("Hours");
		header.add("Turnover");
		
		model.put("header",header);
		
		response.setContentType( "application/ms-excel" );
	    response.setHeader( "Content-disposition", "attachment; filename=Aggregated " + order + " Reports.xls" );  
		
		return new ModelAndView(new ExcelView(),model);
	}
	
	@RequestMapping(value={"/generateDetailReport/{from_dt}/{until_dt}/{taskList}/{departmentList}/{userList}/{orderBy}","/generateDetailReport/{from}/{until}/{taskList}/{departmentList}/{userList}"})
	public ModelAndView generateExcelDetailReport(HttpServletResponse response,
												@PathVariable(value="from") String from,
												@PathVariable(value="until") String until,
												@PathVariable(value="taskList") List<Integer> taskId,
												@PathVariable("departmentList") List<Integer> deptId,
												@PathVariable("userList") List<Integer> userId
												) throws ParseException{
		
		Map<String,Object> model = new HashMap<String,Object>();
		
		model.put("sheetname", "Detailed Report");
		
		Date from1 = format1.parse(from);
		Date until1 = format1.parse(until);
		
		List<Date> range = new ArrayList<Date>();
		range.add(from1);
		range.add(until1);
		
		model.put("dateRange",range);
		
		List<String> header = new ArrayList<String>();
		header.add("Task name");
		header.add("Date");
		header.add("User");
		header.add("Activity Details");
		header.add("Time In");
		header.add("Time out");
		header.add("Hours");
		
		Sort sort_by_task = new Sort(Sort.Direction.ASC,"assignment.user_assignment.task_name");
		List<UserTask> userTask = userTaskRepo.findUserTaskGloballyDetail(from1, until1,taskId,deptId,userId,sort_by_task);
		
		model.put("results",userTask);
		
		model.put("category", 1);
		model.put("header",header);
		
		response.setContentType( "application/ms-excel" );
	    response.setHeader( "Content-disposition", "attachment; filename=Detailed Reports.xls" );  
		
		return new ModelAndView(new ExcelView(),model);
	}
	
	@RequestMapping(value="/myexcel/{from_dt}/{until_dt}/{assignedTask}", method=RequestMethod.GET)
    public ModelAndView getMyData(HttpServletRequest request,
    		HttpServletResponse response,
    		@PathVariable(value="from_dt") String startDate,
    		@PathVariable(value="until_dt") String endDate,
    		@PathVariable(value="assignedTask") List<Integer> assignId,
    		HttpSession session) throws SQLException, ParseException{
		
		int userId = Integer.parseInt(session.getAttribute("userId").toString());
		
		Date startDate1 = format1.parse(startDate);
		Date endDate1 = format1.parse(endDate);
		
		List<Date> range = new ArrayList<Date>();
		range.add(startDate1);
		range.add(endDate1);
		
		List<UserTask> listForReport = userTaskRepo.findBetweenDatesAndAssignedTask(userId, startDate1, endDate1, assignId);
		
		Map<String, Object> model = new HashMap<String, Object>();
	    
	    //Sheet Name
	    model.put("sheetname", "User report");
	    
	    //Headers List
	    List<String> headers = new ArrayList<String>();
	    headers.add("Task");
	    headers.add("Task Code");
	    headers.add("User");
	    headers.add("Rate");
	    headers.add("Hours");
	    
	    model.put("header", headers);
	    
	    //Results Table (List<Object[]>)
	    model.put("results",listForReport);
	    model.put("dateRange",range);
	    model.put("category", 0);
	    
	    response.setContentType( "application/ms-excel" );
	    response.setHeader( "Content-disposition", "attachment; filename=myfile.xls" );  
        
        return new ModelAndView(new ExcelView(), model);
    }
}
