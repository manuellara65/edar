package com.tocedar.project.model;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class SubRoleId implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	Integer id_role;
	Integer id_user;
	
	public SubRoleId(){}
	
	public SubRoleId(Integer id_role,Integer id_user){
		this.id_role = id_role;
		this.id_user = id_user;
	}
	
	public Integer getId_role() {
		return id_role;
	}

	public Integer getId_user() {
		return id_user;
	}

	public void setId_role(Integer id_role) {
		this.id_role = id_role;
	}

	public void setId_user(Integer id_user) {
		this.id_user = id_user;
	}
	
	

	
}
