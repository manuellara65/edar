package com.tocedar.project.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tocedar.project.model.Assignment;
import com.tocedar.project.model.Task;
import com.tocedar.project.model.User;
import com.tocedar.project.model.UserAssigmentList;
import com.tocedar.project.model.UserTask;
import com.tocedar.project.repositories.AssignmentRepository;

@Controller
public class Assignments {
	
	public AssignmentRepository assigmentRepo;
	
	
	@Autowired
	public void setAssigmentRepo(AssignmentRepository assigmentRepo) {
		this.assigmentRepo = assigmentRepo;
	}

	@RequestMapping(value="/admin/assignment/save",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Assignment save(Assignment assign,HttpServletRequest request){
		
		assignmentManagement(assign,request);
		
		List<Assignment> ass = new ArrayList<>();
		
		ass.add(new Assignment(new Task(assign.getUser_assignment().getId()),assign.getUser_id(),assign.getAssignment_type(),assign.getStart_date(),assign.getEnd_date(),assign.getHourly_rate(),assign.getActive(),assign.getNotif_tm_overrun(),assign.getTime_allot(),assign.getAllowed_overrun()));
		
		return assigmentRepo.save(assign);
	}
	
	@RequestMapping(value="/admin/assignment/update",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Assignment update(Assignment assign,HttpServletRequest request){
		
		assignmentManagement(assign,request);
		
		Assignment updateAssignment =  assigmentRepo.findOne(assign.getId_assignment());
		updateAssignment.setActive(assign.getActive());
		updateAssignment.setAllowed_overrun(assign.getAllowed_overrun());
		updateAssignment.setAssignment_type(assign.getAssignment_type());
		updateAssignment.setStart_date(assign.getStart_date());
		updateAssignment.setEnd_date(assign.getEnd_date());
		updateAssignment.setHourly_rate(assign.getHourly_rate());
		updateAssignment.setNotif_tm_overrun(assign.getNotif_tm_overrun());
		updateAssignment.setRole_assignment(assign.getRole_assignment());
		updateAssignment.setTime_allot(assign.getTime_allot());
		updateAssignment.setUser_assignment(assign.getUser_assignment());
		
		return assigmentRepo.save(updateAssignment);
	}
	
	@RequestMapping(value="/admin/get-assignment/{id}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Assignment getAssignmentInfo(@PathVariable int id){
		Assignment assignmentInfo = assigmentRepo.findOne(id);
		
		return assignmentInfo;
	}
	
	@RequestMapping(value="admin/delete-assignment/{id}")
	public @ResponseBody Assignment deleteAssignment(@PathVariable int id){
		
		Assignment searchAssignment = assigmentRepo.findOne(id);
		assigmentRepo.delete(searchAssignment);
		
		return searchAssignment;
	}
	
	@RequestMapping(value="/admin/assignment/multiple-user")
	public @ResponseBody Iterable<Assignment> addAssignmentMultipleUser(Assignment assign,@RequestParam(value="user") String user){
		String[] user1 = user.split(","); 
 		
		List<Assignment> assignment_for_user = new ArrayList<>();
		for(String use:user1){
			assignment_for_user.add(new Assignment(new Task(assign.getUser_assignment().getId()),new User(Integer.parseInt(use)),assign.getAssignment_type(),assign.getStart_date(),assign.getEnd_date(),assign.getHourly_rate(),assign.getActive(),assign.getNotif_tm_overrun(),assign.getTime_allot(),assign.getAllowed_overrun()));
		}
		
		return assigmentRepo.save(assignment_for_user);
	}
	
	public void assignmentManagement(Assignment assign,HttpServletRequest request){
		String notif_overrun = (request.getParameter("notif_tm_overrun") == null) ? "on" : "off";
		
		if(request.getParameter("active") == null){
			assign.setActive("on");
		}else{
			assign.setActive("off");
		}
		
		if(assign.getAssignment_type().equals("Date range")){
			assign.setTime_allot(0);
			assign.setAllowed_overrun(0);
			assign.setNotif_tm_overrun(notif_overrun);
		}else if(assign.getAssignment_type().equals("Time alloted(fixed)")){
			assign.setTime_allot(assign.getTime_allot());
			assign.setAllowed_overrun(0);
			assign.setNotif_tm_overrun(notif_overrun);
		}else if(assign.getAssignment_type().equals("Time alloted(flex)")){
			assign.setTime_allot(assign.getTime_allot());
			assign.setAllowed_overrun(assign.getAllowed_overrun());
			assign.setNotif_tm_overrun(notif_overrun);
		}
		
		if(request.getParameter("startDateRestriction") == null){
			assign.setStart_date(assign.getStart_date());
		}else{
			assign.setStart_date(null);
		}
		
		if(request.getParameter("endDateRestriction") == null){
			assign.setEnd_date(assign.getEnd_date());
		}else{
			assign.setEnd_date(null);
		}
	}
	
	
	
	/*@RequestMapping(value="/admin/assignment/{id}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String assignment(@PathVariable int id,UserAssigmentList assign){
		
		return assigmentRepo.assignment(id);
	}
	
	@RequestMapping(value="/admin/assignmentList/{id}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<UserAssigmentList> assignmentList(@PathVariable int id){
		
		return assigmentRepo.assignedTask(id);
	}*/
}
