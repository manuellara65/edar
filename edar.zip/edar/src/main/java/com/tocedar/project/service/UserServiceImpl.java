package com.tocedar.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.tocedar.project.model.UserCredentials;
import com.tocedar.project.repositories.UserCredentialRepository;

@Component
@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserCredentialRepository userRepository;
	
	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Override
	public void save(UserCredentials user) {
		user.setUsername(user.getUsername());
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		userRepository.save(user);
		
	}

	@Override
	public UserCredentials findByUsername(String username) {
	
		return userRepository.findByUsername(username);
	}

}
