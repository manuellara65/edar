package com.tocedar.project.repositories;

import org.springframework.data.repository.CrudRepository;

import com.tocedar.project.model.UserRoles;

public interface UserRoleRepository extends CrudRepository<UserRoles,Integer>{

	
}
