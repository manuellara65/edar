package com.tocedar.project.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
public class MvcConfig extends WebMvcConfigurerAdapter{

	@Override
	public void addViewControllers(ViewControllerRegistry registry){
		registry.addViewController("/log").setViewName("log");
		registry.addViewController("/signin").setViewName("signin");
		registry.addViewController("/index").setViewName("index");
		registry.addViewController("/logout").setViewName("logout");
		registry.addViewController("/calendar").setViewName("calendar");
		registry.addViewController("/createTaskWeekly").setViewName("createTaskWeekly");
		registry.addViewController("/manage").setViewName("manage");
		registry.addViewController("/admin/*").setViewName("admin");
		registry.addViewController("/main").setViewName("main");
		registry.addViewController("/error/403").setViewName("error/403");
		registry.addViewController("/Reporting/reporting").setViewName("Reporting/user-reporting");
		registry.addViewController("/Reporting/global-reporting").setViewName("Reporting/global-reporting");
	}
}
