package com.tocedar.project.controller;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.neo4j.kernel.logging.SystemOutLogging;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tocedar.project.model.Assignment;
import com.tocedar.project.model.Task;
import com.tocedar.project.model.User;
import com.tocedar.project.repositories.AssignmentRepository;
import com.tocedar.project.repositories.TaskRepository;
import com.tocedar.project.repositories.UserRepository;

@Controller
public class Tasks {
	
	TaskRepository taskRepo;
	UserRepository userRepo;
	
	@Autowired AssignmentRepository assignmentRepository;
	
	@Autowired
	public void setUserRepo(UserRepository userRepo) {
		this.userRepo = userRepo;
	}


	@Autowired
	public void setTaskRepo(TaskRepository taskRepo) {
		this.taskRepo = taskRepo;
	}


	@RequestMapping(value="/admin/tasks")
	public String index(Model model){
		
		model.addAttribute("tasking",new Task());
		model.addAttribute("taskList",taskRepo.findAll());
		model.addAttribute("user_manager",userRepo.findAll());
		
		return "manage/task";
	}
	
	@RequestMapping(value={"/admin/tasks-list"},produces=MediaType.APPLICATION_JSON_VALUE,method=RequestMethod.GET)
	public @ResponseBody List<Task> listTask(@RequestParam(value="active",required=false) boolean act,@RequestParam(value="billable",required=false) boolean bill){
		
		if(act && bill){
			return taskRepo.findByActiveAndBillable("on","on");
		}else if (!act && bill){
			return taskRepo.findByActiveAndBillable("off","on");
		}else if(act && !bill){
			return taskRepo.findByActiveAndBillable("on","off");
		}else if(!act && !bill)
			return taskRepo.findByActiveAndBillable("off","off");
		else
			return taskRepo.findAll();
	}
	
	@RequestMapping(value="/admin/addTask",method=RequestMethod.GET)	
	public @ResponseBody Map<String,Object> saveTask(HttpServletRequest request,Model model,@Valid Task tasks,BindingResult result,Error error){
		
		String bill = (request.getParameter("billable") == null) ? "off" : "on";
		String active1 = (request.getParameter("active") == null) ? "off" : "on";
		String default_task1 = (request.getParameter("default_task") == null) ? "off" : "on";
		
		if(default_task1 == "on"){
			tasks.setUser_assigned("*");
		}else{
			tasks.setUser_assigned("");
		}
		
		Map<String,Object> creatingResult = new HashMap<>();
		
		if(result.hasErrors()){
			creatingResult.put("error", result.getAllErrors());
		}else{
			
			tasks.setBillable(bill);
			tasks.setActive(active1);
			tasks.setDefault_task(default_task1);
			
			creatingResult.put("result",taskRepo.save(tasks));
		}
		
		return creatingResult;
	}
	
	@RequestMapping(value="/admin/filterTask",produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<Task> filterTask(@RequestParam(value="search") String search){
		
		System.out.println("search:"+search);
		
		if(search !=null){
			return taskRepo.findByDescriptionContains(search);
		}
		
		return taskRepo.findAll();
	}
	
	@RequestMapping(value="/admin/fetchTask/{id}",produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Task getInfo(@PathVariable int id,Task task1){
		
		Task task = taskRepo.findOne(id);
		
		task1.setActive(task.getActive());
		task1.setBillable(task.getBillable());
		task1.setCode(task.getCode());
		task1.setContact_person(task.getContact_person());
		task1.setDefault_task(task.getDefault_task());
		task1.setDescription(task.getDescription());
		task1.setId(task.getId());
		task1.setId_manager(task.getId_manager());
		task1.setTask_name(task.getTask_name());
		
		return task1;
	}
	
	@RequestMapping(value="/admin/updateTask",produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Task updateTask(Task task,HttpServletRequest request){
		
		String bill = (request.getParameter("billable") == null) ? "off" : "on";
		String active1 = (request.getParameter("active") == null) ? "off" : "on";
		String default_task1 = (request.getParameter("default_task") == null) ? "off" : "on";
		
		Task updateTask = taskRepo.findOne(task.getId());
		updateTask.setTask_name(task.getTask_name());
		updateTask.setCode(task.getCode());
		updateTask.setId_manager(task.getId_manager());
		updateTask.setDescription(task.getDescription());
		updateTask.setContact_person(task.getContact_person());
		updateTask.setDefault_task(default_task1);
		updateTask.setBillable(bill);
		updateTask.setActive(active1);
		
		if(default_task1 == "on"){
			updateTask.setUser_assigned("*");
		}else{
			updateTask.setUser_assigned("");
		}
		
		return taskRepo.save(updateTask);
	}
	
	@RequestMapping(value="/admin/show-users-to-this-task/{id_task}",produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<Assignment> showUserToThisTask(@PathVariable Integer id_task){
		
		List<Assignment> assignment = assignmentRepository.findUserToThisTask(id_task);
		
		return assignment;
	}
	
	
	
}
