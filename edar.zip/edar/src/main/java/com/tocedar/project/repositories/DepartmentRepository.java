package com.tocedar.project.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;

import com.tocedar.project.model.Departments;

@Transactional
public interface DepartmentRepository extends CrudRepository<Departments,Integer>{

	@Query("UPDATE Departments SET department=?1,code=?2 WHERE id=?3")
	@Modifying
	int updateDepartment(String dept,String code,int id);
	
	public List<Departments> findByDepartmentContaining(String dept);
}
