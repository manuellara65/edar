package com.tocedar.project.repositories;

import java.sql.Time;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;

import com.tocedar.project.model.Assignment;
import com.tocedar.project.model.MyTask;
import com.tocedar.project.model.Task;
import com.tocedar.project.model.User;
import com.tocedar.project.model.UserTask;

@Transactional
public interface UserTaskRepository extends JpaRepository<UserTask,Integer>{
	
	
	
	@PreAuthorize("hasAuthority('ADMIN')")
	@Modifying
	@Query("UPDATE UserTask SET id_task=?2,owner_description=?3,time_in=?4,time_out=?5  WHERE id = ?6")
	int isUpdated(int id_task,String owner_description,Time time_in,Time time_out,int idTaskToUpdate);
	
	public List<UserTask> findAll();
	
    @Query("from Task AS task left JOIN task.userTask AS task1 where task1.id_owner=?1")
	public Task findById2(int ids);
    
    @Query("from User as user LEFT JOIN user.userTask AS user1 where user1.id=?1")
    public List<User> findUserTask(int id);
	
    @Query("from Task as task1 LEFT JOIN task1.userTask AS userTask1 WHERE userTask1.dateCreated=?1")
	public Task findByDateCreated1(Date dt);
    
    @Query("from UserTask AS userTask where (userTask.dateCreated=?1 OR userTask.dateCreated=?2 OR userTask.dateCreated=?3 OR userTask.dateCreated=?4 OR userTask.dateCreated=?5 OR userTask.dateCreated=?6 OR userTask.dateCreated=?7) AND userTask.id_owner=?8 ORDER BY userTask.dateCreated ASC")
    public List<UserTask> findByDateCreated(Date dt,Date dt1,Date dt2,Date dt3,Date dt4,Date dt5,Date dt6,User userId);
    
    @Query("from UserTask AS userTask where userTask.id_owner=?1 AND userTask.dateCreated BETWEEN ?2 AND ?3 ORDER BY userTask.dateCreated ASC")
    public List<UserTask> findBetweenDates(User userId,Date from,Date to);
    
    @Query("from UserTask AS userTask where userTask.id_owner.id=?1 AND userTask.dateCreated BETWEEN ?2 AND ?3 AND userTask.assignment.user_assignment.id IN (?4) ORDER BY userTask.dateCreated ASC")
    public List<UserTask> findBetweenDatesAndAssignedTask(int userId,Date from,Date to,List<Integer> assigned_task_id);
    
    @Query("FROM UserTask AS userTask WHERE userTask.id_owner.id=?1")
    List<UserTask> userTaskCreated(Integer userId);
    
    @Query("FROM UserTask as userTask "
    		+ "WHERE userTask.dateCreated BETWEEN ?1 AND ?2 "
    			+ "AND userTask.assignment.user_assignment.id IN (?3) "
    			+ "AND userTask.id_owner.userDepartment.id IN (?4) "
    			+ "AND userTask.id_owner.id IN (?5) ")
    List<UserTask> findUserTaskGloballyDetail(Date from,Date to,List<Integer> taskId,List<Integer> deptId,List<Integer> userId,Sort sort);
    
    @Query("FROM UserTask as userTask "
    		+ "WHERE userTask.dateCreated BETWEEN ?1 AND ?2 "
    			+ "AND userTask.assignment.user_assignment.id IN (?3) "
    			+ "AND userTask.id_owner.userDepartment.id IN (?4) "
    			+ "AND userTask.id_owner.id IN (?5) ")
    Page<UserTask> findUserTaskGloballyDetail(Date from,Date to,List<Integer> taskId,List<Integer> deptId,List<Integer> userId,Pageable page);
   
    public UserTask findById(int task_created_id);
    
    public void deleteUserTaskById(int id);
}
