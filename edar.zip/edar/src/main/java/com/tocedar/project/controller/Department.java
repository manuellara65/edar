package com.tocedar.project.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tocedar.project.model.Departments;
import com.tocedar.project.model.JsonResponse;
import com.tocedar.project.repositories.DepartmentRepository;

@Controller
public class Department {
	
	DepartmentRepository deptRepo;
	
	@Autowired
	public void setDeptRepo(DepartmentRepository deptRepo1) {
		this.deptRepo = deptRepo1;
	}

	@PreAuthorize("hasAuthority('ADMIN')")
	@RequestMapping(value="/admin/departments")
	public String index(Model model){
		
		model.addAttribute("dept",new Departments());
		model.addAttribute("deptList",deptRepo.findAll());
		
		return "manage/department";
	}
	
	@RequestMapping(value="/admin/list-departments")
	public @ResponseBody List<Department> listDepartment(){
		
		return (List)deptRepo.findAll();
	}
	
	
	@RequestMapping(value="/admin/department/add",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String,Object> add(Model model,@Valid Departments dept,BindingResult result,Error error){
		
		Map<String,Object> creationResult = new HashMap<>();
		
		if(result.hasErrors()){
			creationResult.put("error", result.getAllErrors());
		}else{
			creationResult.put("result", deptRepo.save(dept));
		}
		
		return creationResult;
	}
	
	@RequestMapping(value={"/admin/department/search/{dept}","/admin/department/search/"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<Departments> search(@PathVariable Optional<String> dept){
		
		if(dept.isPresent()){
			return deptRepo.findByDepartmentContaining(dept.get());
		}
			
		return (List)deptRepo.findAll();
		
	}
	
	@PreAuthorize("hasAuthority('ADMIN')")
	@RequestMapping(value="/admin/department/fetchData/{id}",produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Departments fetchData(@PathVariable int id,Departments depts){
		
		Departments dept = deptRepo.findOne(id);
		depts.setCode(dept.getCode());
		depts.setDepartment(dept.getDepartment());
		depts.setId(dept.getId());
		
		return depts;
	}
	
	@RequestMapping(value="/admin/department/edit")
	public @ResponseBody Map<String,Object> editDepartment(Model model,@Valid Departments depts,BindingResult result,Errors error){
		
		Map<String,Object> updateResult = new HashMap<>();
		
		if(result.hasErrors()){
			updateResult.put("error", result.getAllErrors());
		}else{
			
			Departments dept = deptRepo.findOne(depts.getId());
			dept.setCode(depts.getCode());
			dept.setDepartment(depts.getDepartment());
			
			updateResult.put("result", deptRepo.save(dept));
			
		}
		
		return updateResult;
	}
}
