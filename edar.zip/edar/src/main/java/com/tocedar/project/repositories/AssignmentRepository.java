package com.tocedar.project.repositories;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.tocedar.project.model.Assignment;
import com.tocedar.project.model.User;
import com.tocedar.project.model.UserAssigmentList;

@Transactional
@Repository
public interface AssignmentRepository extends CrudRepository<Assignment,Integer>{

	@Query("FROM Assignment AS assign"
			+ " WHERE assign.user_id=?1")
	List<Assignment> assignedTask(User id_owner);
	
	@Query("FROM Assignment AS assign"
			+ " WHERE assign.user_id=?1 AND assign.start_date > ?2 AND assign.end_date < ?3 AND assign.user_assignment.id IN (?4)")
	List<Assignment> findAssignmentForReport(User userId,Date startDate,Date endDate,List<Integer> taskId);
	
	@Query("FROM Assignment AS assign"
			+ " WHERE assign.user_assignment.id = ?1")
	List<Assignment> findUserToThisTask(Integer taskId);
	
	@Query("FROM Assignment AS assign1"
			+ " WHERE assign1.user_id.id=?1")
	List<Assignment> findUserToThisTask1(Integer userId);
	
	
	
}
