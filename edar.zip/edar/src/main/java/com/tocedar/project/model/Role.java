package com.tocedar.project.model;

public enum Role {

	
}
