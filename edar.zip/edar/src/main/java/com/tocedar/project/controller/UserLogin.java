package com.tocedar.project.controller;



import java.security.Principal;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.tocedar.project.model.UserCredentials;
import com.tocedar.project.repositories.AssignmentRepository;
import com.tocedar.project.repositories.UserCredentialRepository;
import com.tocedar.project.service.SecurityService;
import com.tocedar.project.service.UserService;

@Controller
public class UserLogin {

	
	private UserCredentialRepository credentialRepository;

	private Logger log = Logger.getLogger(UserLogin.class);
	
	private SecurityService securityService;
	
	@Autowired
	private AssignmentRepository assignmentRepo;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	public void setSecurityService(SecurityService securityService1) {
		this.securityService = securityService1;
	}

	@Autowired
	public void setCredentialRepository(UserCredentialRepository credentialRepository) {
		this.credentialRepository = credentialRepository;
	}

	@RequestMapping(value="/log",method=RequestMethod.POST)
	public String login(UserCredentials user,Model model,HttpSession session,Principal principal,HttpSession request){
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
		if(auth instanceof AnonymousAuthenticationToken){
			try{
				int userId = securityService.autologin(user.getUsername(), user.getPassword()).getId();
				
				request.setAttribute("userId", userId);
				
				System.out.println("login");
				
			}catch(NullPointerException er){
				return "redirect:/signin?error";
			}
			
			return "redirect:/main";
			
		}else{
			return "redirect:/signin?logout";
		}
		
	}
	
	@RequestMapping(value="/signin",method=RequestMethod.GET)
	public String login(@RequestParam(value="error",required=false) String error,
						@RequestParam(value="logout", required=false) String logout,
						Model model,
						HttpServletRequest request,
						HttpServletResponse response){
		
		model.addAttribute("userLogin",new UserCredentials());
		
		if(error != null){
			model.addAttribute("error","Invalid Username/Password!");
			
			return "login";
		}
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
		System.out.println("hey yow!");
		
		if(logout != null){
			
			System.out.println("hey");
			
	        if (auth != null){    
	            new SecurityContextLogoutHandler().logout(request, response, auth);
	        }
	        
	        model.addAttribute("logout","Logout Success!");
	        
		}
		
		if(!auth.getCredentials().toString().isEmpty()){
			
			System.out.println("credental:"+auth.getCredentials());
			
			return "redirect:/main";
		}
		
		return "login";
		
	}
	
	 @RequestMapping(value="/logout", method = RequestMethod.GET)
	    public String logoutPage () {
	        
	        return "redirect:/signin?logout";
	    }
	
}
