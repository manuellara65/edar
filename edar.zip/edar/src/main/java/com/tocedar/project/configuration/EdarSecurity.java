package com.tocedar.project.configuration;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.thymeleaf.extras.springsecurity4.dialect.SpringSecurityDialect;
import org.thymeleaf.spring4.SpringTemplateEngine;

import com.tocedar.project.repositories.AssignmentRepository;
import com.tocedar.project.service.UserDetailsServiceImpl;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(securedEnabled = true,prePostEnabled=true)
@Order(SecurityProperties.ACCESS_OVERRIDE_ORDER)
@ComponentScan(basePackageClasses=UserDetailsServiceImpl.class)
public class EdarSecurity extends WebSecurityConfigurerAdapter{
	private Logger log = Logger.getLogger(EdarSecurity.class);
	
	private UserDetailsService userDetailsService;
	
	@Autowired
	public void setUserDetailsService(UserDetailsService userDetailsService) {
		this.userDetailsService = userDetailsService;
	}
	
	@Bean
	public BCryptPasswordEncoder bCryptPasswordEncoder(){
		return new BCryptPasswordEncoder();
	}
	
	@Override
	public void configure(HttpSecurity httpSecurity) throws Exception{
		
		
		httpSecurity
			.authorizeRequests()
			.antMatchers("/images/**",
						"/style/**",
						"/webjars/bootstrap/3.3.6/js/**",
						"/webjars/bootstrap/3.3.6/css/**",
						"/webjars/jquery/2.2.4/**",
						"/webjars/jquery-ui/1.12.0/**").permitAll();
		
		httpSecurity
			.authorizeRequests()
				.antMatchers("/","/log","/signin")
				.permitAll()
				.antMatchers("/calendar","/calendar/*/*","/user/createTaskWeekly/*","/user/***","/user-reporting","/main").hasAuthority("USER")
				.antMatchers("/manage","/admin/*","/admin/*/*","/admin***").hasAuthority("ADMIN")
				.antMatchers("/report/***").hasAuthority("REPORTING")
				.antMatchers("/index").hasAnyAuthority("ADMIN","USER","REPORTING")
				.anyRequest().fullyAuthenticated()
			.and()
				.exceptionHandling().accessDeniedPage("/error/403")
			.and()
				.formLogin()
					.loginPage("/signin")
					.usernameParameter("username").passwordParameter("password")
					.loginProcessingUrl("/login")
					.defaultSuccessUrl("/index")
					.failureUrl("/signin?error")
			.and()
				.logout()
				.logoutSuccessUrl("/logout")
				.permitAll();
		
			log.info("Configure success");
	
	}
	
	
	@Autowired
	public void configureAuthentication(AuthenticationManagerBuilder auth) throws Exception{
		auth.userDetailsService(userDetailsService).passwordEncoder(bCryptPasswordEncoder());
	}
	
	
}
