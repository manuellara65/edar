package com.tocedar.project.repositories;

import java.util.List;

import javax.ws.rs.DELETE;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.tocedar.project.model.SubRole;
import com.tocedar.project.model.User;

@Repository
@Transactional
public interface SubRoleRepository extends CrudRepository <SubRole,Integer> {

	/*@Modifying
	@Query(value="INSERT INTO SubRole(role,user1) VALUE(?1, ?2)",nativeQuery = true)
	void saveSubRole(int role,int user_id);*/
	
	@Modifying
	@DELETE
	@Query(value="DELETE FROM SubRole AS subRole WHERE subRole.user1=?1")
	void DeleteByUserId(User id);
	
}
