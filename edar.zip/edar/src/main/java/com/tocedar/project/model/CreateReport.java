package com.tocedar.project.model;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

public class CreateReport {

	Date until_dt;
	Date from_dt;
	int reportType;
	List<Integer> deptList;
	List<Integer> taskList;
	List<Integer> userList;
	
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	public Date getUntil_dt() {
		return until_dt;
	}
	public void setUntil_dt(Date until_dt) {
		this.until_dt = until_dt;
	}
	

	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	public Date getFrom_dt() {
		return from_dt;
	}
	public void setFrom_dt(Date from_dt) {
		this.from_dt = from_dt;
	}
	public List<Integer> getDeptList() {
		return deptList;
	}
	public void setDeptList(List<Integer> deptList) {
		this.deptList = deptList;
	}
	public List<Integer> getTaskList() {
		return taskList;
	}
	public void setTaskList(List<Integer> taskList) {
		this.taskList = taskList;
	}
	public List<Integer> getUserList() {
		return userList;
	}
	public void setUserList(List<Integer> userList) {
		this.userList = userList;
	}
	public int getReportType() {
		return reportType;
	}
	public void setReportType(int reportType) {
		this.reportType = reportType;
	}
	
	
	
	
}
