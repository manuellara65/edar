package com.tocedar.project.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tocedar.project.model.Timesheet;
import com.tocedar.project.repositories.TimesheetRepository;

@Controller
public class Timesheets {
	
	TimesheetRepository timesheetRepo;
	
	@Autowired
	public void setTimesheetRepo(TimesheetRepository timesheetRepo) {
		this.timesheetRepo = timesheetRepo;
	}

	@RequestMapping(value="/admin/timesheets")
	public String index(Model model){
		model.addAttribute("timesheet",new Timesheet());
		model.addAttribute("timesheetList",timesheetRepo.findAll());
		
		return "manage/timesheet";
	}
	
	@RequestMapping(value="/admin/timesheets/filter",produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<Timesheet> filter(@RequestParam(value="search") String search){
	
		if(search != null){
			return timesheetRepo.findByTimesheetNameContaining(search);
		}
		
		return (List) timesheetRepo.findAll();
	}
	
	@RequestMapping(value="/admin/timesheets/save")
	public @ResponseBody Map<String,Object> save(Model model,@Valid Timesheet timesheet,BindingResult result,Error error,HttpServletRequest request){
		
		Map<String,Object> saveResult = new HashMap<>();
		
		if(result.hasErrors()){
			saveResult.put("error", result.getAllErrors());
		}else{
			String active = (request.getParameter("active") == null) ? "off" : "on";
			timesheet.setActive(active);
			
			saveResult.put("result", timesheetRepo.save(timesheet));
		}
		
		return saveResult;
	}
	
	@RequestMapping(value="/admin/timesheets/update",produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Timesheet update(Timesheet ts,HttpServletRequest request){
		
		String active = (request.getParameter("active") == null) ? "off" : "on";
		
		Timesheet tm = timesheetRepo.findOne(ts.getId());

		tm.setEndDate(ts.getEndDate());
		tm.setFromDate(ts.getFromDate());
		tm.setTimesheetName(ts.getTimesheetName());
		tm.setToDate(ts.getToDate());
		
		tm.setActive(active);

		//timesheetRepo.updateTimesheet(ts.getTimesheetName(), ts.getEndDate(), ts.getFromDate(), ts.getToDate(), ts.getActive(), ts.getId());
		
		return timesheetRepo.save(tm);
	}
	
	@RequestMapping(value="/admin/timesheets/fetchValue/{id}",produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Timesheet fetchValue(@PathVariable int id,Timesheet ts){
		
		Timesheet result = timesheetRepo.findOne(id);
		ts.setTimesheetName(result.getTimesheetName());
		ts.setActive(result.getActive());
		ts.setEndDate(result.getEndDate());
		ts.setFromDate(result.getFromDate());
		ts.setToDate(result.getToDate());
		
		return ts;
	}
	
	
	
}
