//<![CDATA[
$(document).ready(function(){
	
	console.log("select#position:"+$("select#position").val());
	
	if($("select#position").val() == 0){
		$("select#subRole option[value='1']").remove();
	}
	
	$("select#position").on("change",function(){
		
		position($(this).val());
	});
	
	function position(pos){
		if(pos == "staff"){
			$("select#subRole option[value='1']").remove();
		}else{
			$("select#subRole option[value='1']").remove();	
			$("select#subRole").append("<option value='1'>ADMIN</option>");
		}
	}
	
	$("#createUser").click(function(){
		clear();
		$("#fieldChangeCredential").show();
		$("#change-credential").hide();
		
		$("#btnUpdate").hide();
		$("#btnSubmit").show();
		
		$("#mdlAddUser").modal();
	});
	
	$("#changeCredential").click(function(){
		$(this).val(function(i,v){
			return v === 'Dont Change Credential...' ? 'Change Credential...' : 'Dont Change Credential...';
		});
		$("#fieldChangeCredential").slideToggle();
	});
	
   $("#btnSubmit").click(function(event){
	   
		   event.preventDefault();
			
			$.ajax({
				type:'GET',
				url:$("#frmCreateUser").attr("action"),
				data:$("#frmCreateUser").serialize(),
				success:function(response){
					 var resp = response;
					
    				  if(resp.error == null){
    					  alert("Created successfully!");
    					  var user_info = resp.user;
    					 
    					  clear();
    					  
    					  	var viewInfo = '<a class="btn-link" href="/admin/user-info/' + user_info.id + '">View Information</a>';
							var assignment = '<a class="btn-link" href="/admin/get-user-assignment/' + user_info.id + '">Assignment</a>';
							var edit = '<a class="btn-link" href="/admin/get-user-info/' + user_info.id + '" id="lnkEdit">Edit</a>';
							
							var stat;
								
							if (user_info.status == 1){
									stat = '<a class="status btn-link" id="status_' + user_info.id + '" href="/admin/activation/0/' + user_info.id+ '" >Deactivate</a>';
								}
							else{
									stat = '<a class="status btn-link" id="status_' + user_info.id + '" href="/admin/activation/1/' + user_info.id+ '" >Activate</a>';
								}
							
							var action = '<div class="btn-group">'
												+ '<button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>'
												+ '<ul class="dropdown-menu" role="menu">'	
													+'<li>' + viewInfo + '</li>'
													+'<li>' + assignment + '</li>'
													+'<li>' + edit + '</li>'
													+'<li>' + stat + '</li>'
												+ '</ul>'
										+ '</div>';
    					  
    					  $("#mdlAddUser").modal("hide");
    					  
    					  var checkbox_id = '<input type="checkbox" value="' + user_info.id + '"/>';
    					  
    					  $("#tblUserList").append('<tr class="row">'
    							  						+ '<td>' + checkbox_id + '</td>'
    							  						+ '<td>' + user_info.id + '</td>'
    							  						+ '<td>' + user_info.lastname + ' ' + user_info.firstname + '</td>'
    							  						+ '<td>' + user_info.email + '</td>'
    							  						+ '<td>' + action + '</td>'
    					  							+ "</tr>");
    					  
    				  }else{
    					 
      				  	$.each(resp.error,function(index,value){
      				  		var val = value.field.replace(".","_");
      					  	$("."+val).text(value.defaultMessage);
      				 		
  						});
    					  
    				  }
				},
				error:function(error){
					alert("Error while adding username "+username+"!Please try again!");
				}
			});
	});
   
   function clear(){
	  $("#frmCreateUser input[type='text']").val('');
	  $("#frmCreateUser input[type='password']").val('');
	  $("#frmCreateUser span[id='validation']").val('');
	  $(".subRole").text('');
	  
	  $("#frmCreateUser #id").val(0);
	  $("#frmCreateUser #user_cred").val(0);
	  
	  $("#frmCreateUser #subRole option").prop("selected",false);
   }
   
   $(document).on("click",".row #lnkEdit",function(event){
	   
	   event.preventDefault();
	   
	   $("#btnSubmit").hide();
		$("#btnUpdate").show();
	   
	   $.ajax({
		   type:'GET',
		   url:$(this).attr('href'),
		   success:function(response){
			   var id_role = [];
			   
			   var user_info = response;
			   var role_user = user_info.subRole;
			   $.each(role_user,function(index,value){
				   id_role.push(value.role.user_role_id);
			   });
			   
			   var ir = id_role.join(",");

			   position(user_info.position);
			   
			   $("#id").val(user_info.id);
			   $("select#userDepartment").val(user_info.userDepartment.id);
			   $("select#position").val(user_info.position);
			   $("#firstname").val(user_info.firstname);
			   $("#lastname").val(user_info.lastname);
			   $("#email").val(user_info.email);
			   $(".username").val(user_info.user_cred.username);
			   
			   
			  // $("#status").val(user_info.status);
			   
			   if(user_info.status == 1){
				   $(".active").attr("checked",true);
				   
			   }else{
				   $(".inactive").attr("checked",true);
			   }
			   
			   $("select#subRole").val(ir.split(","));
			   
			   $("#fieldChangeCredential").hide();
			   $("#change-credential").show();
			   
			   $("#mdlAddUser").modal();
		   },
		   error:function(error){
			   
		   }
		   
	   });
	   
   });
   
   $("#btnUpdate").click(function(){
	   
	   var isChangePass = $("#changeCredential").val();
	   var url4Change;
	   if(isChangePass == "Change Credential..."){
		   url4Change = '/admin/updateUser/1';
	   }else{
		   url4Change = '/admin/updateUser/0';
	   }
	   
	   $.ajax({
		  type:'GET',
		  url:url4Change,
		  data:$("#frmCreateUser").serialize(),
		  success:function(response){
			  var resp = response;
			  
			  $("#frmCreateUser span").text("");
			  
			  if(resp.Error == null){
				  alert("Updated successfully!");
				  
				  $("#mdlAddUser").modal("hide");
				  
			  }else{
				  	
  				  	$.each(resp.Error,function(index,value){
  				  		var val = value.field.replace(".","_");
  					  	$("."+val).text(value.defaultMessage);
					});
				  
			  }
		  },
		  error:function(error){
			  alert("Error updating user information!");
		  }
	   });
   });
});

//]]>