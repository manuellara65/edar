// task management
	 $(document).ready(function() {

			$("#createTaskForm").submit(function(event) {

				event.preventDefault();
				
				var description = $("#owner_description").val();
				var time_in = $("#time_in").val();
				var time_out = $("#time_out").val();
				if(description == ""){
						alert("Missing description field");
					}
				else{
					
					if(time_in == "")
						$("#time_in").val("00:00:00");
					
					if(time_out == ""){
						$("#time_out").val("00:00:00");
					}
						
					
					$.ajax({
						type:'get',
						url: $("#createTaskForm").attr("action"),
						data:$("#createTaskForm").serialize(),
						success:function(response){
							
							alert("Successfully added!");
							
							$(document).ready(reset2);
							
							displayList(response);
						},
						error:function(e){
							alert("error");
						}
						
					});
				}
			});
		});
	
	 
	 	function displayList(response){

	 		 var tblRow = "";
	 		 var hrefLink;
	 	     var link;
	 	     var id;
	 	     var open = "";
	 	     var progress = "";
	 	     var close ="";
	 	     var time_consume = '0.0';
	 	     var time_out="";
	 	     var time_in="";
	 	     var ttl_time_consume_hour=0;
	 	     var ttl_time_consume_minute=0;
	 	     
	 	    var ttl_minute=0;
	 	    var ttl_hr=0;
	 	    
	 	    $("#table-task tbody").remove();
	 	     
			 $.each(response,function(index){
				
				    id = response[index][6];
					
					var taskProgress="";
					
					time_in = response[index][3];
					time_out = response[index][4];
					
					var splt_time_in = time_in.split(":");
					var splt_time_out = time_out.split(":");
					
					var status = response[index][1];
					
					if(time_out == '00:00:00'){
						time_consume = '0.0'
					}
					else{
						var time_out_to_minute = (parseInt(splt_time_out[0]) * 60) + parseInt(splt_time_out[1]); //get total minutes of timeout
						var time_in_to_minute = (parseInt(splt_time_in[0]) * 60) + parseInt(splt_time_in[1]); //get total minutes of time in
						var thour = parseInt((time_out_to_minute - time_in_to_minute)/60); //get hours
						var time_min = ((time_out_to_minute - time_in_to_minute)%60); //get minutes
						
						time_consume = Number(parseInt(thour) + "." +time_min); // time consumed
						
						ttl_time_consume_hour +=thour;
						ttl_time_consume_minute += time_min;
						
						//time_consume = (parseInt(splt_time_out[0]) - splt_time_in[0]) +"."+(splt_time_out[1]-splt_time_in[1]);
					}
					
					link = '<a href="#modalCreateTask" id="editLink" data-toggle="modal" onClick="editTask('+id+')">Edit</a>';
					
					var task = "<div class='uTask'>" +
									"<div class='pull-right' style='width:auto;'>"+ link +"</div></br>" +
									"<div>"+response[index][5]+"<div>" +
									"<div>Time-in:&nbsp;"+time_in+"<div>" +
									"<div>Time-out:&nbsp;"+time_out+"<div>" +
								"</div>";
					
				    hrefLink = '/edit/'+id;
										
					open = (status=='Open') ? task : '';
					progress = (status=='In-progress') ? task : '';
					close = (status=='Close') ? task : '';
					
					tblRow += '<tbody><tr><td>' + open + '</td><td>' + progress + '</td><td>' + close + '</td><td>' + time_consume + '</td></tr></tbody>';
					
					open = "";
					progress = "";
					close = "";
					
				});
			ttl_hr = parseInt(ttl_time_consume_minute/60);
	 		ttl_minute = ttl_time_consume_minute - (ttl_hr*60);
	 		
			var total_time_alloted = ttl_hr + ttl_time_consume_hour + "." + ttl_minute;
	 	
			$(".ttl_time_consumed").html(total_time_alloted);
	 		$("#table-task").append(tblRow);
	 	}
	 
		function displayVals() {
			  var singleValues = $( "#sprintList" ).val();
			  $("#id_owned_sprint").val(""+singleValues);

		}
		 
		$("#sprintList").change(displayVals);
		
		function displayTime(){
			var selectHour = $("#time_in_hour").val();
			var selectMinute = $("#time_in_minute").val();
			
			$("#time_in").val(selectHour+":"+selectMinute+":00");
		
			return selectHour;
		}
		
		function displayTimeMinute(){
			var selectMinute = $("#time_in_minute").val();
			$("#time_in").val(displayTime()+":"+selectMinute+":00");
		}
		
		$("#time_in_minute").change(displayTimeMinute);
		$("#time_in_hour").change(displayTime);
		
		function displayOutTime(){
			var selectHour = $("#time_out_hour").val();
			var selectMinute = $("#time_out_minute").val();
			
			$("#time_out").val(selectHour+":"+selectMinute+":00");
		
			return selectHour;
		}
		
		function displayOutTimeMinute(){
			var selectMinute = $("#time_out_minute").val();
			$("#time_out").val(displayOutTime()+":"+selectMinute+":00");
		}
		
		$("#time_out_minute").change(displayOutTimeMinute);
		$("#time_out_hour").change(displayOutTime);
		
		
		$("#sprintList").change(function(displayVals){
			var singleValues = $( "#sprintList" ).val();
			var sprint_owned = singleValues;
			
			$.ajax({
				type:'GET',
				url:"/getSprintList/"+sprint_owned,
				contentType:"application/json",
				dataType:"json",
				success:function(response){
					
					displayList(response);
					
				},
				error:function(e){
					alert("error");
				}
			});
		});
		
		displayVals();
		
		//edit task
		function editTask(id){
			$(document).ready(function(){
				$.ajax({
					type:'GET',
					url:"/getTaskInfo/"+id,
					contentType:"application/json",
					datatype:"json",
					success:function(response){
						var res = JSON.stringify(response);
						var time_in = response.time_in.split(":");
						var time_out = response.time_out.split(":");
						
						var updateButton = "<a id='updateMyTask' class='btn btn-success' onclick='updateThisTask("+ response.id +")'>Update</a>";
						
						$("#status option").filter(function(){
							return $(this).text() == response.status;
						}).prop("selected",true);
						
						$("#id_task option").filter(function(){
							return $(this).val() == response.id_task;
						}).prop("selected",true);
						
						$("#owner_description").val(response.owner_description);
						
						$("#time_in_hour option").filter(function(){
							return $(this).val() == ""+time_in[0];
						}).prop("selected",true);
						
						$("#time_in_minute option").filter(function(){
							return $(this).val() == ""+time_in[1];
						}).prop("selected",true);
						
						$("#time_out_hour option").filter(function(){
							return $(this).val() == ""+time_out[0];
						}).prop("selected",true);
						
						$("#time_out_minute option").filter(function(){
							return $(this).val() == ""+time_out[1];
						}).prop("selected",true);
						
						$("#time_in").val(response.time_in);
						$("#time_out").val(response.time_out);
						
						$(".modal-footer").html(updateButton);
						
					},
					error:function(error){
						alert("Error while sending request.Please try again!");
					}
				});
			});
		}
		
		function updateThisTask(thisTaskId){
			
			$(document).ready(function(event){
				
				$.ajax({
					type:'GET',
					url:'/editThisTask/'+thisTaskId,
					data:$("#createTaskForm").serialize(),
					success:function(response){
						$("#modalCreateTask").modal("hide");
						displayList(response.value);
					},
					error:function(error){
						alert("Error updating task!");
					}
				});
			});
		}
		
		//show modal
		$("#modalCreateSprint").click(function(){
			$("#myModalCreateSprint").modal();
		});
	
		//reset form for create task
		function reset(){
			$("#btnModalCreateTask").click(function(){
				$("#modalCreateTask").modal();
				reset2();
			});
		}
		
		$(document).ready(reset);
		
		function reset2(){
			
			var saveButton = "<input type='submit' class='btn btn-success'/>";

			$("#owner_description").val("");
			
			$("#status option").filter(function(){
				return $(this).val() == "Open";
			}).prop("selected",true);
			
			$("#time_in_hour option").filter(function(){
				return $(this).val() == "00";
			}).prop("selected",true);
			$("#time_in_minute option").filter(function(){
				return $(this).val() == "00";
			}).prop("selected",true);
			
			$("#time_out_hour option").filter(function(){
				return $(this).val() == "00";
			}).prop("selected",true);
			$("#time_out_minute option").filter(function(){
				return $(this).val() == "00";
			}).prop("selected",true);
			
			$("#time_in").val("00:00:00");
			$("#time_out").val("00:00:00");
			
			$(".modal-footer").html(saveButton);
		}

//Sprint management
		
		